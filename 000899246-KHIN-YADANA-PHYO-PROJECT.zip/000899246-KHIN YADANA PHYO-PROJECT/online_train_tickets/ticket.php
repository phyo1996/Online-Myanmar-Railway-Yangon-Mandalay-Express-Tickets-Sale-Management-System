<?php
  
?>
<html>
    <head>
    </head>
    <body>
        <?php
session_start();
include "./mysql_connect.php";
$customer_id=$_SESSION['customerid'];
$bookingid = $_SESSION['bookingid'];
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
</head>

<body>
<form action="" method="post">
    <div class="logo">
        <div class="logo_word">
            <img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
               <div class="button">
        <ul>
            <li>
            <a href="index.php">Home</a>    
            </li>
                    <?php if(isset($_SESSION['customername']))
                     { ?>
                    <li><a href="search.php">Schedule</a></li>
                    <li><a href="ticket.php">Ticket</a></li>
                    <li><a href="logout.php">Logout</a></li>
                    <?php } else {?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                    <?php } ?>
            <li>
            <a href="contact.php">Contact</a>    
            </li>
        </ul>
</div>
    
    </div>
    <div class="above">
        <div class="Login">
        <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Your Ticket</span> 
                </div>
        <div class="ticket_print">
         <table border="2" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top: 30px; color:fuchsia;">
                        <tr bgcolor="cyan" style="color:fuchsia;">
                            <th>ID_Number</th>
                            <th>UserName</th>
                            <th>From_Station</th>
                            <th>To_Station</th>
                            <th>Depature_Date</th>
                             <th>Price</th>  
                            <th></th>
                            <th></th>
                        </tr>
                           <?php $result = mysqli_query($connection, "select   tic.idnumber
                                                                      ,        tic.travellername
                                                                      ,        rou.fromstation
                                                                      ,        rou.tostation
                                                                      ,        sch.depaturedate
                                                                      From     booking as boo
                                                                      ,        ticket as tic
                                                                      ,        scheduledetail as schd
                                                                      ,        route as rou
                                                                      ,        schedulecarriage as schcar
                                                                      ,        schedule as sch
                                                                      where    boo.bookingid = tic.bookingid
                                                                      and      schd.routeid = rou.routeid
                                                                      and      schd.schedulecarriageid = tic.schedulecarriageid
                                                                      and      schcar.schedulecarriageid = schd.schedulecarriageid
                                                                      and      schcar.scheduleid = sch.scheduleid
                                                                      and      schd.routeid = tic.routeid
                                                                      and      tic.bookingid = 'B001';");                  
                        while($row = mysqli_fetch_array($result)) { ?>    
                        <tr>
                            <td><?php //echo $; ?></td>
                            <td><?php echo $index[1]; ?></td>
                            <td><?php echo $_SESSION['fromstation']; ?></td>
                            <td><?php echo $_SESSION['tostation']; ?></td>
                            <td><?php echo $_SESSION["depaturedate"]; ?></td> 
                            <td><?php echo $userseat[2]; ?></td>  
                            <td><a href="editcustomer.php?updateid=<?php echo $row[0]; ?>">Update</a></td>
                            <td><a href="editcustomer.php?deleteid=<?php echo $row[0]; ?>">Delete</a></td>

                        </tr>
                        <?php } ?>
                    </table>
        <div>
        </div>
    
    </div>
    </form>
</body>
</html>

    </body>
</html>
