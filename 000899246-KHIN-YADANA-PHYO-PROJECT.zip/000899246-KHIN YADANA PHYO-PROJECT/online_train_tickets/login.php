<?php
    session_start();
    include "./mysql_connect.php";
    if(isset($_SESSION["customerid"])) {
        echo "<script>alert('Please log out to log in again.'); location.assign('index.php');</script>";
    }
    
    if(isset($_POST["log-button"]))
    {
        $login_email = $_POST["log-email"];
        $login_password = $_POST["log-password"];
        $statement = $connection->prepare("SELECT custommerid,customername,customercontactphone,email,password FROM customer WHERE email = ?");
        $statement->bind_param('s', $login_email);
        $statement->execute();
        $statement->bind_result($customer_id,$customer_name,$customer_contact_phone,$customer_email,$customer_password);
        if($statement->fetch()) {
            if(password_verify($login_password, $customer_password)) {
                $_SESSION['customerid'] = $customer_id;
                $_SESSION['customername'] = $customer_name;
                $_SESSION['customercontactphone'] = $customer_contact_phone;
                $_SESSION['email'] = $customer_email;
                $statement->close();
                if(isset($_GET["scheduleid"])) {
                    $sid = $_GET["scheduleid"];
                    header("Location: seat.php?scheduleid=$sid");
                }
                else {
                    header("Location: search.php");
                }
            }
            else {
                $statement->close();
                echo "<script>alert('Wrong email and password.');</script>";
            }
        }
        else {
            $statement = $connection->prepare("SELECT staffid, staffname, staffrole,st.stationid,stationname,password FROM staff s, station st WHERE s.stationid=st.stationid AND email = ?");
            $statement->bind_param('s', $login_email);
            $statement->execute();
            $statement->bind_result($staff_id, $staff_name, $staff_role, $staff_station, $staff_stationname, $staff_password);
            if($statement->fetch()) {
                if(password_verify($login_password, $staff_password)) {
                    $_SESSION['staffid'] = $staff_id;
                    $_SESSION['staffname'] = $staff_name;
                    $_SESSION['staffrole'] = $staff_role;
                    $_SESSION['stationid'] = $staff_station;
                    $_SESSION['stationname'] = $staff_stationname;
                    $statement->close();
                    if($staff_role == "Admin") {
                        header("Location: registerstaff.php");
                    }
                    else {
                        header("Location: closestation.php");
                    }
                }
                else {
                    $statement->close();
                    echo "<script>alert('Wrong email and password.');</script>";
                }
            }
            else {
                $statement->close();
                echo "<script>alert('Wrong email and password.');</script>";
            }
        }
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <form action="" method="post">
            <div class="logo">
                <div class="logo_word">
                    <img src="images/200px-Myanma_Railway.svg.png" height="90px">
                </div>
                <div class="button">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="registercustomer.php">Register</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="search.php">Search</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="above" style="height: 700px;">
                <div class="Login">
                    <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Log-In</span>
                </div>
                <div class="box">
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Email</span> <input type="text" name="log-email" class="log-text" required/>
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Password</span> <input type="password" name="log-password" class="log-text">
                    </div>
                    <div>
                        <input type="submit" name="log-button" value="LOG-IN" width="400px" class="but">
                    </div>
                </div>  
            </div>
        </form>
    </body>
</html>
