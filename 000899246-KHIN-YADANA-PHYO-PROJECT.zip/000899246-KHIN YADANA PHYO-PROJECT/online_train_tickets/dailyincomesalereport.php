<?php
    session_start();
    include "./mysql_connect.php";
    
    $reportdate = "";
    if(isset($_POST["produce"]))
    {
        $reportdate = (isset($_POST["reportdate"]))? $_POST["reportdate"]: "";
    }
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
         </script>
        
        <link rel="stylesheet" href="js/Datepicker/themes/ui-lightness/jquery.ui.all.css">
        <script src="js/jquery-2.1.1.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.core.min.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.datepicker.min.js"></script>
</head>
 <script>
    $(function() {
        $("#reportdate").datepicker();
        $("#reportdate").datepicker("option", "dateFormat", "yy-mm-dd");
        $("#reportdate").datepicker("option", "changeMonth", true);
        $("#reportdate").datepicker("option", "changeYear", true);
        $("#reportdate").datepicker("setDate", "<?php echo $reportdate; ?>");
    });
</script>
<body>
<form action="" method="post" name="dailyincomereport">
    <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php" style="color: #0099cc;">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
    <div class="above">
        <div class="reportheader" style="width: 300px;">
    <marquee direction="right" class="reportword">Online Myanmar Railway</marquee>
    </div>
        <div class="Login">
            <span class="Login-word" style="margin-left:0px; font-size:29px; font-weight:bold;">Daily Ticket Sale Report</span>
        </div>
        <div class="box">
      <div class="nn">
              <span style="font-family:Cooper; color:orange; font-size:21px;">Report Date</span><input type="text" name="reportdate" id="reportdate" value="" style="width: 147px; height: 25px;"  />
                                <input type="button" value="Clear" name="clear" onclick="document.dailyincomereport.reportdate.value=''; submit();" style="height: 33px; margin-left: -10px;" />
            </div>
            <input type="submit" name="produce" value="Produce" width="400px" class="but">
            <input type="submit" name="cancel-carriage" value="Cancel" width="400px" class="but">
        </div>
         <?php
    
    
    if(isset($_POST["produce"]))
    {
   ?>
       <table border="2" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top: 30px; color:fuchsia;">
                        <tr bgcolor="cyan" style="color:fuchsia;">
                            <th>From Station</th>
                            <th>To Station</th>
                            <th>SeatType Name</th>
                            <th>Price</th>
                        </tr>
    <?php $result = mysqli_query($connection, "Select     r.fromstation
                                                , r.tostation
                                                , seat.seattypename
                                                , SUM(price)
                                                From     schedulecarriage as schcar
                                                ,          carriage as car
                                                ,          seattype  as seat
                                                ,          scheduledetail as schd
                                                ,          ticket as tic
                                                ,          route as r
                                                ,          routeprice as rp
                                                ,        booking as book
                                                where    book.bookingid = tic.bookingid
                                                and      schd.schedulecarriageid   = tic.schedulecarriageid
                                                and        schcar.schedulecarriageid = schd.schedulecarriageid
                                                and        schcar.carriageid = car.carriageid
                                                and        car.seattypeid    = seat.seattypeid
                                                and      seat.seattypeid = rp.seattypeid
                                                and        r.routeid = rp.routeid
                                                and      r.routeid = schd.routeid
                                                and      r.routeid = tic.routeid
                                                and     book.bookingdate = '$reportdate'
                                                GROUP BY seat.seattypename"); 
                while($row = mysqli_fetch_array($result)) { ?>
                        <tr>
                            <td><?php echo $row[0]; ?></td>
                            <td><?php echo $row[1]; ?></td>
                            <td><?php echo $row[2]; ?></td>
                            <td><?php echo $row[3]; ?></td>
                        </tr>
                        <?php } ?>
                    </table>  
        
   <?php     

        
    }
    
       
?>

        </div>
           

    </div>
    </form>
</body>
</html>
