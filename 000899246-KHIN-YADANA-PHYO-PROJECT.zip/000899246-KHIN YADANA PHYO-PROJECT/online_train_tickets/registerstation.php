<?php
    session_start();
    include "./mysql_connect.php";

    if(!isset($_SESSION["staffid"])) {
        echo "<script>alert('Please log in to access this file.'); location.assign('login.php');</script>";
    }
    if($_SESSION["staffrole"] != "Admin") {
        echo "<script>alert('You can\'t access this file.'); location.assign('login.php');</script>";
    }
    
    $stationid ="";
    $stationname = "";

    if(isset($_POST["register-station"])) {
        $stationid = $_POST["stationid"];
        $stationname = $_POST["stationname"];
        if(!isset($_GET["updateid"])) {
            $result = mysqli_query($connection, "INSERT INTO station VALUES('$stationid', '$stationname')");
        }
        else {
            $result = mysqli_query($connection, "UPDATE station SET stationname = '$stationname' WHERE stationid = '$stationid'");
        }
        if($result) {
            echo "<script>alert('Successful Register.'); location.assign('registerstation.php');</script>";
        }
        else {
            echo "<script>alert('Error in register.');</script>";
        }
    }
     
    if(isset($_GET["updateid"])) {
        $stationid = $_GET["updateid"];
        $result = mysqli_query($connection, "SELECT * FROM station WHERE stationid = '$stationid'");
        $row = mysqli_fetch_array($result);
        $stationid = $row[0];
        $stationname = $row[1];
    }
    
    if(isset($_GET["deleteid"])) {
        $stationid = $_GET["deleteid"];
        $result = mysqli_query($connection, "DELETE FROM station WHERE stationid = '$stationid'");
        if($result) {
            echo "<script>alert('Successful Delete.'); location.assign('registerstation.php');</script>";
        }
        else {
            echo "<script>alert('Your station is used and can't delete.'); location.assign('registerstation.php');</script>";
        }
    }
    
    if(isset($_POST["cancel-station"])) {
        header("location: registerstation.php");
    }
    
    if(empty($stationid)) {
        $result = mysqli_query($connection, "SELECT MAX(stationid) FROM station");
        $stationid = "S001";
        if($row = mysqli_fetch_assoc($result)) {
            $maxid = $row["MAX(stationid)"];
            $newid = substr($maxid, 1) + 1;
            $stationid = "S".str_pad($newid, 3, "0", STR_PAD_LEFT);
        }
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <form action="" method="post">
            <div class="logo">
                <div class="logo_word">
                    <img src="images/200px-Myanma_Railway.svg.png" height="90px">
                </div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php" style="color: #0099cc;">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
            <div class="above">
                <div class="Login">
                    <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Station</span>
                </div>
                <div class="box">
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Station ID</span> <input type="text"  readonly name="stationid" class="log-text" value="<?php echo $stationid; ?>">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Station Name</span> <input type="text" name="stationname" class="log-text" value="<?php echo $stationname; ?>" required maxlength="25" pattern="[a-zA-Z][a-zA-Z0-9 .]+">
                    </div>
                    <div>
                        <input type="submit" name="register-station" value="<?php echo isset($_GET["updateid"])? 'Update': 'Register'; ?>" width="400px" class="but">
                        <input type="submit" name="cancel-station" value="Cancel" width="400px" class="but" formnovalidate>
                    </div>
                </div>
        
                <table border="4" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top:30px; color:#DA70D6; margin-bottom: 30px;" >
                    <tr bgcolor="cyan" style="color:#DA70D6;">
                        <th>Station ID</th>
                        <th>Station Name</th>
                        <th></th>
                        <th></th>
                    </tr>
                    <?php
                        $result = mysqli_query($connection, "SELECT * FROM station ORDER BY stationid");
                        while($row = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row[0]; ?></td>
                        <td><?php echo $row[1]; ?></td>
                        <td><a href="registerstation.php?updateid=<?php echo $row[0]; ?>">Update</a></td>
                        <td><a href="registerstation.php?deleteid=<?php echo $row[0]; ?>" onclick="return confirm('Are you sure to delete?');">Delete</a></td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </form>
    </body>
</html>
