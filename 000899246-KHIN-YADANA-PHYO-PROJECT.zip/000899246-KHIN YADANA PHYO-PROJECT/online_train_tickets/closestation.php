<?php
session_start();
include "./mysql_connect.php";
$stationid = $_SESSION['stationid'];
$trainid = "";
$realdepaturetime="";


if(isset($_POST['closestation']))
{
 $scheduleid = $_GET['updateid'];
 $realdepaturetime=$_POST['hour'] . ":" . $_POST['minute'] . ":" . $_POST['second'];
  $depaturestatus=1;   
  
  $result =mysqli_query($connection, "update schedulestation set realdepaturetime = '$realdepaturetime', depaturestatus = $depaturestatus where scheduleid = '$scheduleid' AND stationid = '$stationid'");

    echo "<script>alert('Success update for real departure time.');location.assign('closestation.php');</script>";
}
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
</head>

<body>
<form action="" method="post">
    <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php" style="color: #0099cc;">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
    <div class="above" style="height:800px;">
        <div class="Login">
            <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Close Station</span>
        </div>
        <div class="box">
        <?php
             if(!isset($_GET['updateid']))
               {
        ?>
                        <div class="nn">

    <span style="font-family:Cooper; color:orange; font-size:21px;">Select Train</span>
                <select name="train"  class="log-text">
                                    <option value="">Select Train</option>
                                    <?php
                                        $result = mysqli_query($connection, "SELECT trainid,trainname FROM train");
                                        while($row = mysqli_fetch_array($result)) {
                                            $sta = ($trainid== $row[0])? "selected": "";
                                    ?>
                                    <option value="<?php echo $row[0]; ?>" <?php echo $sta; ?>><?php echo $row[1]; ?></option>
                                    <?php } ?>
                 </select>
            </div>
             
               <?php
               }
               if(isset($_GET['updateid']))
               {
               ?>
                <div class="nn">
                    <span style="font-family:Cooper; color:orange; font-size:16px;">Real Departure Time</span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <br>
                    <select name="hour" required>
                        <option value="">Select Hour</option>
                        <?php for($i = 0; $i < 24; $i++) {echo "<option value='". $i. "'>$i</option>";} ?>
                    </select>
                    <select name="minute" required>
                        <option value="">Select Minute</option>
                        <?php for($i = 0; $i < 60; $i++) {echo "<option value='". $i. "'>$i</option>";} ?>
                    </select>
                    <select name="second" required>
                        <option value="">Select Second</option>
                        <?php for($i = 0; $i < 60; $i++) {echo "<option value='". $i. "'>$i</option>";} ?>
                    </select>
                </div><br>
                          <input type="submit" name="closestation" value="Close" width="400px" class="but">  
               <?php
               }if(!isset($_GET['updateid']))
               {
               ?>
            <input type="submit" name="repare" value="Prepare To Close" width="400px" class="but">
            <?php } ?>
        

        <div class="nn" style="width: 800px; margin: auto;">
          <?php
          if(isset($_POST['repare']))
          {
           $trainid = $_POST['train'];   
          ?>
         <table border="4" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top:70px; margin-left:-90px; color:#DA70D6;" >
                        <tr bgcolor="cyan" style="color:#DA70D6;">
                            <th>Train Name</th>
                            <th>Schedule ID</th>
                            <th>Station Name</th>
                            <th>Departure Date</th>
                            <th>Proposed Departure Time</th>
                        </tr>
                        <?php 
                        //$tra = mysqli_query($connection,"select train_id from train where trainname = '$traid'");
                        //$convert = $tra.tostring();
//                        echo $stationid;
//                        echo $trainid;
                        $result = mysqli_query($connection, "Select            tra.trainname
                                                                    ,          sch.*
                                                                    From       train tra
                                                                    ,          schedule sch
                                                                    ,		   schedulestation schs
                                                                    where      tra.trainid = sch.trainid
                                                                    and		   schs.scheduleid = sch.scheduleid
                                                                    and		   schs.stationid = 'S001'
                                                                    and        tra.trainid = 'T001'
                                                                    and        (sch.depaturedate = curdate() or sch.depaturedate = curdate() - interval 1 Day)
                                                                    and        Concat(sch.scheduleid, 'S001') In (select Concat(scheduleid, stationid) from schedulestation)
                                                                    and		   depaturestatus IS NULL;
                        ;"); 
                                                                    while($row = mysqli_fetch_array($result)) { 
                                                                        $result1 = mysqli_query($connection, "SELECT stationname FROM station WHERE stationid = '$stationid'");
                                                                        $row1 = mysqli_fetch_array($result1);
                                                                        ?>
                        <tr>
                            <td><?php echo $row[0]; ?></td>
                            <td><?php echo $row[1]; ?></td>
                            <td><?php echo $row1[0]; ?></td>
                            <td><?php echo $row[3]; ?></td> 
                            <td><?php echo $row[4]; ?></td> 
                           
                            <td><a href="closestation.php?updateid=<?php echo $row[1]; ?>">Update</a></td>
                            
                        </tr>
                        <?php } ?>
                    </table>
                                               <?php } ?>

                    </div>
                    
                    

    
        
    </div></div>
    </form>
</body>
</html>
