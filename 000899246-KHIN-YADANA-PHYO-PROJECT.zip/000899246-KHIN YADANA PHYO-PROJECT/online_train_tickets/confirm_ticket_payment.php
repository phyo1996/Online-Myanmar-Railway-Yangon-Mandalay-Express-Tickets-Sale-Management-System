<?php
session_start();
include "./mysql_connect.php";
  if(isset($_POST["confirm"]))
  {
      
          $result = mysqli_query($connection, "SELECT MAX(paymentid) FROM payment");
        $paymentid = "P0000001";
        if($row = mysqli_fetch_assoc($result)) {
            $maxid = $row["MAX(paymentid)"];
            $newid = substr($maxid, 1) + 1;
            $paymentid = "P".str_pad($newid, 7, "0", STR_PAD_LEFT);
      $bookingid = array_pop(array_keys($_POST["confirm"]));
      $paymentdate = $_POST["paymentdate"];
      $staffid = $_SESSION['staffid'];
      
      $result = mysqli_query($connection,"INSERT INTO payment VALUES('$paymentid', '$paymentdate[$bookingid]','$bookingid','$staffid')");   
      echo "<script>alert('Payment is successful'); </script>"; 
                                                                          }
  }
      
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
     </script>
        
        <link rel="stylesheet" href="js/Datepicker/themes/ui-lightness/jquery.ui.all.css">
        <script src="js/jquery-2.1.1.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.core.min.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.datepicker.min.js"></script>
</head>
<body>
    <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php" style="color: #0099cc;">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
    <div class="above">
        <div class="Login" style="width: 440px;">
            <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Confirm Tickets</span>
        </div>
        <div class="box" style="height: 400px; width: 900px; margin-bottom: 40px;">
            <form method="POST">
         <table border="2" bordercolor="yellow" bgcolor="cyan" width="100%" height="auto" style="margin-top: 30px; color:fuchsia;">
                        <tr bgcolor="cyan" style="color:fuchsia;">
                            <th>Booking ID</th>  
                            <th>Booking Date</th>
                            <th>Price</th>
                            <th>Customer Name</th>
                            <th>Customer Email</th>
                            <th>Payment Date</th>
                        </tr>
                        <?php
                        $fromstation = $_SESSION["stationid"];
                        $result = mysqli_query($connection, "select boo.bookingid,bookingdate,SUM(price),cus.customername,cus.email
                                                                    From   booking as boo
                                                                    ,      ticket as tic
                                                                    ,      schedulecarriage as schcar
                                                                    ,      carriage as car
                                                                    ,      route as rou
                                                                    ,      routeprice as roup
                                                                    ,      customer as cus
                                                                    where  boo.bookingid = tic.bookingid
                                                                    and    tic.schedulecarriageid = schcar.schedulecarriageid
                                                                    and    schcar.carriageid = car.carriageid
                                                                    and    car.seattypeid = roup.seattypeid
                                                                    and    roup.routeid = rou.routeid
                                                                    and    rou.routeid = tic.routeid
                                                                    and    cus.custommerid = boo.customerid
                                                                    and    boo.bookingid Not In(select bookingid from payment)
                                                                    and    rou.fromstation = '$fromstation'
                                                                    GROUP BY boo.bookingid"); 
while($row = mysqli_fetch_array($result)) { ?>
                        <form method="POST"
                        <tr>
                            <td><?php echo $row[0]; ?></td>
                            <td><?php echo $row[1]; ?></td>
                            <td><?php echo $row[2]; ?></td>
                            <td><?php echo $row[3]; ?></td>
                            <td><?php echo $row[4]; ?></td>
                            
                            <script>
    $(function() {
        $("#paymentdate<?php echo $row[0]; ?>").datepicker();
        $("#paymentdate<?php echo $row[0]; ?>").datepicker("option", "dateFormat", "yy-mm-dd");
        $("#paymentdate<?php echo $row[0]; ?>").datepicker("option", "minDate", "0");
        $("#paymentdate<?php echo $row[0]; ?>").datepicker("option", "changeMonth", true);
        $("#paymentdate<?php echo $row[0]; ?>").datepicker("option", "changeYear", true);
    });
</script>
                            
                            <td> <input type="text" name="paymentdate[<?php echo $row[0]; ?>]" id="paymentdate<?php echo $row[0]; ?>" value="" required style="width: 147px; height: 25px;"  />
                                <input type="button" value="Clear" name="clear" onclick="document.getElementById('paymentdate<?php echo $row[0]; ?>').value='';"/></td>    
                            
                            <td><input type="submit" name="confirm[<?php echo $row[0]; ?>]" value="Confirm Payment"/></td>
                        </tr>
                        
                        <?php } ?>
                    </table>
                </form>
            </div>
        </div>
        
    </div>
</body>
</html>
