<?php
    session_start();
    include "./mysql_connect.php";
    $depaturedate = "";
    $depaturetime = "";
    $trainid = "";
    if(isset($_POST['s1']))
    {
        $trainid = $_POST["trainid"];
    }
    if(isset($_POST['Save']))
    {
        $scheduleid = $_POST['sche'];
        $depaturedate = $_POST["dd"];  
        $depaturetime = $_POST["dt"];
        $trainid = $_POST['trainid'];
        $_SESSION['registertrain'] = $scheduleid.",".$depaturedate.",".$depaturetime.",".$trainid; 
        echo "<script>alert('Successful Register.'); location.assign('register_schedule_2.php');</script>";
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
        
        <link rel="stylesheet" href="js/Datepicker/themes/ui-lightness/jquery.ui.all.css">
        <script src="js/jquery-2.1.1.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.core.min.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.datepicker.min.js"></script>
        <script>
            $(function() {
                $("#dd").datepicker();
                $("#dd").datepicker("option", "dateFormat", "yy-mm-dd");
                $("#dd").datepicker("option", "minDate", "+1d");
                $("#dd").datepicker("option", "maxDate", "+1m");
                $("#dd").datepicker("option", "changeMonth", true);
                $("#dd").datepicker("option", "changeYear", true);
                $("#dd").datepicker("setDate", "<?php echo $depaturedate; ?>");
            });
        </script>
    </head>
 
    <body>
        <form action="" method="post">
            <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php" style="color: #0099cc;">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
            <div class="above">
                <div class="Login">
                    <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Draw schedule</span>
                </div>
                <div class="box" style="height: 380px;">
                    <span style="font-family:Cooper; color:orange; font-size:21px;">Select Train</span>
                    <select name="trainid"  class="log-text">
                        <option value="">Select Train</option>
                        <?php
                            $result = mysqli_query($connection, "SELECT trainid,trainname FROM train");
                            while($row = mysqli_fetch_array($result)) {
                                $sta = ($trainid== $row[0])? "selected": "";
                        ?>
                        <option value="<?php echo $row[0]; ?>" <?php echo $sta; ?>><?php echo $row[1]; ?></option>
                        <?php } ?>
                    </select><br/>
                   <input type="submit" value="Draw Train for schedule" name="s1" />
                </div>
                <?php
                    if(isset($_POST['s1']))
                    {
                        $result = mysqli_query($connection, "SELECT MAX(scheduleid) FROM schedule");
                        $sche = "Sch001";
                        if($row = mysqli_fetch_assoc($result)) {
                            $maxid = $row["MAX(scheduleid)"];
                            $newid = substr($maxid, 3) + 1;
                            $sche = "Sch".str_pad($newid, 3, "0", STR_PAD_LEFT);
                        }
                        $result = mysqli_query($connection, "SELECT trainname FROM train WHERE trainid='$trainid'");
                        $row = mysqli_fetch_assoc($result);
                        $trainname = $row["trainname"];
                ?>
                <table border="4" bordercolor="yellow" bgcolor="maroon" width="100%" style="margin-top:30px; color:cyan;" >
                    <tr bgcolor="cyan" style="color:#FF1493;">
                        <th>Schedule ID</th>
                        <th>Schedule Date</th>
                        <th>Departure Date</th>
                        <th>Departure Time</th>
                        <th>Train Name</th>                                                     
                        <th>To Save</th>
                    </tr>
                    <tr>
                        <td><?php echo $sche;?></td>
                        <input type="hidden" name="sche" value="<?php echo $sche;?>" />
                        <td><input type="text" name="scheuduledate" id="st" value="<?php echo date('Y-m-d') ?>" style="width: 147px; height: 25px;" readonly /> </td>
                        <td><input type="text" name="dd" id="dd" value=""></td>
                        <td>
                            <select name="dt" required><option value="">Select Time</option>
                                <option value="5:00:00">5:00 AM</option><option value="6:00:00">6:00 AM</option>
                                <option value="7:00:00">7:00 AM</option><option value="8:00:00">8:00 AM</option>
                                <option value="9:00:00">9:00 AM</option><option value="10:00:00">10:00 AM</option>
                                <option value="11:00:00">11:00 AM</option><option value="12:00:00">12:00 NOON</option>
                                <option value="13:00:00">1:00 PM</option><option value="14:00:00">2:00 PM</option>
                                <option value="15:00:00">3:00 PM</option><option value="16:00:00">4:00 PM</option>
                                <option value="17:00:00">5:00 PM</option><option value="18:00:00">6:00 PM</option>
                                <option value="19:00:00">7:00 PM</option><option value="20:00:00">8:00 PM</option>
                                <option value="21:00:00">9:00 PM</option><option value="22:00:00">10:00 PM</option>
                                <option value="23:00:00">11:00 PM</option><option value="00:00:00">12:00 MIDNIGHT</option>
                            </select>
                        </td>
                        <td><?php echo $trainname;?></td> 
                        <input type="hidden" name="trainid" value="<?php echo $trainid;?>" /> 
                        <td><input type="submit" name="Save" value="Save"></td>
                    </tr>
                </table>
                <?php
                    }
                ?>
            </div>
        </form>
    </body>
</html>
