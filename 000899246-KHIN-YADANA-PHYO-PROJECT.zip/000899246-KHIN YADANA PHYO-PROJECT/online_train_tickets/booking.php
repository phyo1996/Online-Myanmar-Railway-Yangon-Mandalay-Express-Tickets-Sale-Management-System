<?php
    session_start();
    include "./mysql_connect.php";              
     
    if(isset($_GET["deleteid"]))
    {
         $del_book = $_GET["deleteid"];
         unset($_SESSION["userseat"][$del_book ]);
    }
    
    if(isset($_POST["purchase"]))
    {
        
        $customerid=  $_SESSION['customerid'];
        $result = mysqli_query($connection, "SELECT MAX(bookingid) FROM booking");
        $bookingid = "B0000001";
        if($row = mysqli_fetch_assoc($result)) {
        $maxid = $row["MAX(bookingid)"];
        $newid = substr($maxid, 1) + 1;
        $bookingid = "B".str_pad($newid, 7, "0", STR_PAD_LEFT);
        }
        $insert_book = mysqli_query($connection, "Insert into booking Values('$bookingid',curdate(),'$customerid')");
        $_SESSION["bookingid"] = $bookingid;
        
        $idnumber = $_POST["idnumber"];
        $travellername = $_POST["name"];
        
         foreach($_SESSION["userseat"] as $index => $userseat) {
         
        $result = mysqli_query($connection, "SELECT MAX(ticketid) FROM ticket");
        $ticketid = "Tic00001";
        if($row = mysqli_fetch_assoc($result)) {
        $maxid = $row["MAX(ticketid)"];
        $newid = substr($maxid, 5) + 1;
        $ticketid = "Tic".str_pad($newid, 5, "0", STR_PAD_LEFT);
        }
        $userseat = split(",", $userseat);
        $result = mysqli_query($connection,"insert into ticket Values('$ticketid','$userseat[8]','$travellername[$index]','$idnumber[$index]','$userseat[5]','$userseat[6]','$bookingid')");
    
    }
    unset($_SESSION["userseat"]);
        echo "<script>alert('Success booking.');location.assign('search.php');</script>";
    }
    
    if(!isset($_SESSION["userseat"]) || sizeof($_SESSION["userseat"]) == 0) {
        echo "<script>alert('You have no seats to book.');location.assign('search.php');</script>";
    }
        
    ?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="./css/style.css">     
</head>
<body>
<form name="book" method="post">
    <div class="logo">
        <div class="logo_word">
            <img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
               <div class="button">
        <ul>
            <li>
            <a href="index.php">Home</a>    
            </li>
                    <?php if(isset($_SESSION['customername']))
                     { ?>
                    <li><a href="search.php">Schedule</a></li>
                    <li><a href="ticket.php">Ticket</a></li>
                    <li><a href="logout.php">Logout</a></li>
                    <?php } else {?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                    <?php } ?>
            <li>
            <a href="contact.php">Contact</a>    
            </li>
        </ul>
</div>
    
    </div>
    <div class="above">
        <div class="Login">
            <span class="Login-word" style="margin-left:120px; font-size:21px; font-weight:bold;">Booking Information</span>
        </div>
        <div class="box" style="height: 500px; margin-bottom: 40px;">
            <div class="nn" style="margin-left: -200px; width: 1000px;">
                <table border="2" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top: 30px; margin-left:-20px; color:fuchsia; margin-left:-25px;">
                        <tr bgcolor="cyan" style="color:fuchsia;">
                            <th>Train Name</th>
                            <th>From Station</th>
                            <th>To Station</th>
                            <th>Depature Date</th>
                            <th>Seat Type</th>
                            <th>Price</th>
                            <th>Carriage No</th>
                            <th>Seat No</th>
                            <th>ID number</th>
                            <th>Traveller Name</th>
                            <th></th>
                            
                            <th></th>
                        </tr>
                        <?php
                            foreach($_SESSION["userseat"] as $index => $userseat) {
                                $userseat = split(",", $userseat);
                                $result = mysqli_query($connection, "select price,trainname
                                From   routeprice as rp
                                ,      route as r
                                ,      seattype as st
                                ,      schedule s
                                ,      schedulecarriage sch
                                ,      carriage c
                                ,      train t
                                Where  rp.routeid = r.routeid
                                and    rp.seattypeid = st.seattypeid
                                and    t.trainid = s.trainid
                                and    s.scheduleid = sch.scheduleid
                                and    sch.carriageid = c.carriageid
                                and    c.seattypeid = st.seattypeid
                                and    r.fromstation='$userseat[1]'
                                and    r.tostation='$userseat[2]'
                                and    st.seattypename='$userseat[4]'");
                            if($row = mysqli_fetch_array($result)) {
                
                        ?>
                        <tr>
                            <td><?php echo $row[1];?></td>
                            <?php $r1 = mysqli_query($connection, "SELECT stationname FROM station WHERE stationid = '$userseat[1]'"); $row1 = mysqli_fetch_array($r1); ?>
                            <td><?php echo $row1[0];?></td>
                            <?php $r2 = mysqli_query($connection, "SELECT stationname FROM station WHERE stationid = '$userseat[2]'"); $row2 = mysqli_fetch_array($r2); ?>
                            <td><?php echo $row2[0];?></td>
                            <td><?php echo $userseat[3];?></td>
                            <td><?php echo $userseat[4] ;?></td>
                            <td><?php echo $row[0] ;?></td>
                            <td><?php echo $userseat[7];?></td>
                            <td><?php echo $userseat[8] ;?></td>
                            <td><input type="text"  name="idnumber[<?php echo $index; ?>]" /></td>
                            <td><input type="text"  name="name[<?php echo $index; ?>]" /></td>
                            <td><a href="booking.php?deleteid=<?php echo $index; ?>">Delete</a></td>
                        </tr>
                        <?php
                            }
                            }
                        ?>
                    </table>
                    <br/>
                     <div class="nn">
                <span style="font-family:Cooper; color:wheat; font-size:21px;"> Bank Name</span> <input type="text" name="customeremail" value="Myanmar Economic Cooperation" class="log-text" readonly/>
            </div>
            <div class="nn">
                <span style="font-family:Cooper; color:wheat; font-size:21px;"> Bank Title</span> <input type="text" name="customerpassword" value="0110011" class="log-text" readonly/>
            </div>
            
            <div class="nn">
           <input type="submit" name="purchase" value="Purchase">
            </div>
            
            


        </div>
        
    </div>
    </div>
    </form>
</body>
</html>
