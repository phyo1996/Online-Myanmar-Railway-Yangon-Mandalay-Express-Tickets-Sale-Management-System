<?php
    session_start();
    include "./mysql_connect.php";

    if(!isset($_SESSION["staffid"])) {
        echo "<script>alert('Please log in to access this file.'); location.assign('login.php');</script>";
    }
    if($_SESSION["staffrole"] != "Admin") {
        echo "<script>alert('You can\'t access this file.'); location.assign('login.php');</script>";
    }
    
    $routeid ="";
    $fromstation = "";
    $tostation = "";
    $travellingtime = "";
    $miles = "";
    $restingtime = "";

    if(isset($_POST["register-route"])) {
        $routeid = $_POST["routeid"];
        $fromstation = $_POST["fromstation"];
        $tostation = $_POST["tostation"];
        $travellingtime = $_POST["travellingtime"];
        $miles = $_POST["miles"];
        $restingtime = $_POST["restingtime"];
        
        if($fromstation == $tostation) {
            echo "<script>alert('From Station and To Station is same.');</script>";
        }
        else {
            if(!isset($_GET["updateid"])) {
                $result = mysqli_query($connection, "SELECT * FROM route WHERE fromstation = '$fromstation' AND tostation = '$tostation'");
                if($row = mysqli_fetch_assoc($result)) {
                    echo "<script>alert('Route already exists. Change another station.');</script>";
                }
                else {
                    $result = mysqli_query($connection, "INSERT INTO route VALUES('$routeid', '$fromstation', '$tostation', '$travellingtime', $miles, '$restingtime')");

                    if($result) {
                        echo "<script>alert('Successful Register.'); location.assign('registerroute.php');</script>";
                    }
                    else {
                        echo "<script>alert('Error in register.');</script>";
                    }
                }
            }
            else {
                $result = mysqli_query($connection, "SELECT * FROM route WHERE fromstation = '$fromstation' AND tostation = '$tostation' AND routeid != '$routeid'");
                if($row = mysqli_fetch_assoc($result)) {
                    echo "<script>alert('Route already exists. Change another station.');</script>";
                }
                else {
                    $result = mysqli_query($connection, "UPDATE route SET fromstation = '$fromstation', tostation = '$tostation', travellingtime = '$travellingtime', miles = $miles, restingtime = '$restingtime' WHERE routeid = '$routeid'");

                    if($result) {
                        echo "<script>alert('Successful Update.'); location.assign('registerroute.php');</script>";
                    }
                    else {
                        echo "<script>alert('Error in update.');</script>";
                    }
                }
            }
        }
    }
     
    if(isset($_GET["updateid"])) {
        $routeid = $_GET["updateid"];
        $result = mysqli_query($connection, "SELECT * FROM route WHERE routeid = '$routeid'");
        $row = mysqli_fetch_array($result);
        $routeid = $row[0];
        $fromstation = $row[1];
        $tostation = $row[2];
        $travellingtime = $row[3];
        $miles = $row[4];
        $restingtime = $row[5];
    }
    
    if(isset($_GET["deleteid"])) {
        $routeid = $_GET["deleteid"];
        $result = mysqli_query($connection, "DELETE FROM route WHERE routeid = '$routeid'");
        if($result) {
            echo "<script>alert('Successful Delete.'); location.assign('registerroute.php');</script>";
        }
        else {
            echo "<script>alert('Your route is used and can't delete.'); location.assign('registerroute.php');</script>";
        }
    }
    
    if(isset($_POST["cancel-route"])) {
        header("location: registerroute.php");
    }
    
    if(empty($routeid)) {
        $result = mysqli_query($connection, "SELECT MAX(routeid) FROM route");
        $routeid = "R001";
        if($row = mysqli_fetch_assoc($result)) {
            $maxid = $row["MAX(routeid)"];
            $newid = substr($maxid, 1) + 1;
            $routeid = "R".str_pad($newid, 3, "0", STR_PAD_LEFT);
        }
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <form action="" name="frm" method="post">
            <div class="logo">
                <div class="logo_word">
                    <img src="images/200px-Myanma_Railway.svg.png" height="90px">
                </div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php" style="color: #0099cc;">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
            <div class="above">
                <div class="Login">
                    <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Route</span>
                </div>
                <div class="box" style="height: 380px;">
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Route ID</span> <input type="text"  readonly name="routeid" class="log-text" value="<?php echo $routeid; ?>">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">From Station</span>
                        <select name="fromstation"  class="log-text" required>
                            <option value="">Select Station</option>
                            <?php
                                $result = mysqli_query($connection, "SELECT stationid,stationname FROM station");
                                while($row = mysqli_fetch_array($result)) {
                                    $sta = ($fromstation == $row[0])? "selected": "";
                            ?>
                            <option value="<?php echo $row[0]; ?>" <?php echo $sta; ?>><?php echo $row[1]; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">To Station</span>
                        <select name="tostation"  class="log-text" required>
                            <option value="">Select Station</option>
                            <?php
                                $result = mysqli_query($connection, "SELECT stationid,stationname FROM station");
                                while($row = mysqli_fetch_array($result)) {
                                    $sta = ($tostation == $row[0])? "selected": "";
                            ?>
                            <option value="<?php echo $row[0]; ?>" <?php echo $sta; ?>><?php echo $row[1]; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Travelling Time</span> <input type="text" name="travellingtime" class="log-text" value="<?php echo $travellingtime; ?>" required maxlength="8" pattern="[0-9]{2}:[0-9]{2}:[0-9]{2}">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Miles</span> <input type="text" name="miles" class="log-text" value="<?php echo $miles; ?>" required maxlength="10" pattern="[0-9]*[.]?[0-9]+">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Resting Time</span> <input type="text" name="restingtime" class="log-text" value="<?php echo $restingtime; ?>" required maxlength="8" pattern="[0-9]{2}:[0-9]{2}:[0-9]{2}">
                    </div>
                    <div>
                        <input type="submit" name="register-route" value="<?php echo isset($_GET["updateid"])? 'Update': 'Register'; ?>" width="400px" class="but">
                        <input type="submit" name="cancel-route" value="Cancel" width="400px" class="but" formnovalidate>
                    </div>
                </div>
        
                <table border="4" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top:30px; color:#DA70D6; margin-bottom: 30px;" >
                    <tr bgcolor="cyan" style="color:#DA70D6;">
                        <th>Route ID</th>
                        <th>From Station</th>
                        <th>To Station</th>
                        <th>Travelling Time</th>
                        <th>Miles</th>
                        <th>Resting Time</th>
                        <th></th>
                        <th></th>
                    </tr>
                    <?php
                        $result = mysqli_query($connection, "SELECT r.routeid, f.stationname, t.stationname, travellingtime, miles, restingtime FROM route r, (SELECT routeid, stationname FROM route r, station s WHERE r.fromstation = s.stationid) f, (SELECT routeid, stationname FROM route r, station s WHERE r.tostation = s.stationid) t WHERE r.routeid = f.routeid AND r.routeid = t.routeid ORDER BY routeid");
                        while($row = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row[0]; ?></td>
                        <td><?php echo $row[1]; ?></td>
                        <td><?php echo $row[2]; ?></td>
                        <td><?php echo $row[3]; ?></td>
                        <td><?php echo $row[4]; ?></td>
                        <td><?php echo $row[5]; ?></td>
                        <td><a href="registerroute.php?updateid=<?php echo $row[0]; ?>">Update</a></td>
                        <td><a href="registerroute.php?deleteid=<?php echo $row[0]; ?>" onclick="return confirm('Are you sure to delete?');">Delete</a></td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </form>
    </body>
</html>
