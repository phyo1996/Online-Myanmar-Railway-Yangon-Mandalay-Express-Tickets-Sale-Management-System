<?php
    session_start();
    include("./mysql_connect.php");
    if(isset($_SESSION["customerid"])) {
        echo "<script>alert('Please log out to get new register.'); location.assign('index.php');</script>";
    }
    
    $customer_id ="";
    $customer_name="";
    $customer_contanct_phone="";
    $customer_email="";
    $customer_password="";
    $customer_repassword=""; 

    if(isset($_POST["register-customer"])) {
        $customer_name=$_POST["customername"];
        $customer_contanct_phone=$_POST["customercontanctphone"];
        $customer_email=$_POST["customeremail"];
        $customer_password=$_POST["customerpassword"];
        $customer_repassword=$_POST["customerrepassword"];
    
        if($customer_password != $customer_repassword) {
            echo "<script>alert('Re-password must be same as Password.');</script>";
        }
        else {
            $result = mysqli_query($connection, "SELECT email FROM customer WHERE email = '$customer_email' UNION SELECT email FROM staff WHERE email = '$customer_email'");
            if($row = mysqli_fetch_assoc($result)) {
                echo "<script>alert('Email already exists. Use another email address');</script>";
            }
            else {
                $result = mysqli_query($connection, "SELECT MAX(custommerid) FROM customer");
                $customer_id = "C0000001";
                if($row = mysqli_fetch_assoc($result)) {
                    $maxid = $row["MAX(custommerid)"];
                    $newid = substr($maxid, 1) + 1;
                    $customer_id = "C".str_pad($newid, 7, "0", STR_PAD_LEFT);
                }
                $customer_password = password_hash($customer_password, PASSWORD_DEFAULT);
                $result = mysqli_query($connection, "INSERT INTO customer VALUES('$customer_id', '$customer_name', '$customer_contanct_phone', '$customer_email', '$customer_password')");

                if($result) {
                    echo "<script>alert('Successful Register.'); location.assign('login.php');</script>";
                }
                else {
                    echo "<script>alert('Error in register.');</script>";
                }
            }
        }
    }
    
    if(isset($_POST["cancel-customer"])) {
        header("location: registercustomer.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <form method="post">
            <div class="logo">
                <div class="logo_word">
                    <img src="images/200px-Myanma_Railway.svg.png" height="90px">
                </div>
                <div class="button">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="registercustomer.php">Register</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="search.php">Search</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="above">
                <div class="Login">
                    <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Register</span>
                </div>
                <div class="box" style="height:400px;">
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;">Name</span> <input type="text" name="customername" value="<?php echo $customer_name; ?>" required maxlength="25" pattern="[a-zA-Z][a-zA-Z0-9 .]+" class="log-text">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;">Contact Phone</span> <input type="text" name="customercontanctphone" value="<?php echo $customer_contanct_phone; ?>" required maxlength="20" pattern="[0-9][0-9\- ]+" class="log-text">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;"> Email</span> <input type="email" name="customeremail" value="<?php echo $customer_email; ?>" required maxlength="50" class="log-text">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;"> Password</span> <input type="password" name="customerpassword" value="" required maxlength="20" class="log-text">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;">Re-password</span> <input type="password" name="customerrepassword" value="" required maxlength="20" class="log-text">
                    </div>
                    <div>
                        <input type="submit" name="register-customer" value="Register" width="400px" class="but">
                        <input type="submit" name="cancel-customer" value="Cancel" width="400px" class="but" formnovalidate>
                    </div>
                </div>
            </div>
        </form>
    </body>
</html>
