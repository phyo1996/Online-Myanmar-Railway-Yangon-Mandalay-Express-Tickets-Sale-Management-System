<?php
    session_start();
    include "./mysql_connect.php";

    if(!isset($_SESSION["staffid"])) {
        echo "<script>alert('Please log in to access this file.'); location.assign('login.php');</script>";
    }
    if($_SESSION["staffrole"] != "Admin") {
        echo "<script>alert('You can\'t access this file.'); location.assign('login.php');</script>";
    }
    
    $carriageid ="";
    $seattypeid = "";
    $totalseat = "";
    $seatperrow = "";

    if(isset($_POST["register-carriage"])) {
        $carriageid = $_POST["carriageid"];
        $seattypeid = $_POST["seattypeid"];
        $totalseat = $_POST["totalseat"];
        $seatperrow = $_POST["seatperrow"];
        
        if(!isset($_GET["updateid"])) {
            $result = mysqli_query($connection, "INSERT INTO carriage VALUES('$carriageid', '$seattypeid', $totalseat, $seatperrow)");
        }
        else {
            $result = mysqli_query($connection, "UPDATE carriage SET seattypeid = '$seattypeid', totalseat = $totalseat, seatperrow = $seatperrow WHERE carriageid = '$carriageid'");
        }
        if($result) {
            echo "<script>alert('Successful Register.'); location.assign('registercarriage.php');</script>";
        }
        else {
            echo "<script>alert('Error in register.');</script>";
        }
    }
     
    if(isset($_GET["updateid"])) {
        $carriageid = $_GET["updateid"];
        $result = mysqli_query($connection, "SELECT * FROM carriage WHERE carriageid = '$carriageid'");
        $row = mysqli_fetch_array($result);
        $carriageid = $row[0];
        $seattypeid = $row[1];
        $totalseat = $row[2];
        $seatperrow = $row[3];
    }
    
    if(isset($_GET["deleteid"])) {
        $carriageid = $_GET["deleteid"];
        $result = mysqli_query($connection, "DELETE FROM carriage WHERE carriageid = '$carriageid'");
        if($result) {
            echo "<script>alert('Successful Delete.'); location.assign('registercarriage.php');</script>";
        }
        else {
            echo "<script>alert('Your carriage is used and can't delete.'); location.assign('registercarriage.php');</script>";
        }
    }
    
    if(isset($_POST["cancel-carriage"])) {
        header("location: registercarriage.php");
    }
    
    if(empty($carriageid)) {
        $result = mysqli_query($connection, "SELECT MAX(carriageid) FROM carriage");
        $carriageid = "C001";
        if($row = mysqli_fetch_assoc($result)) {
            $maxid = $row["MAX(carriageid)"];
            $newid = substr($maxid, 1) + 1;
            $carriageid = "C".str_pad($newid, 3, "0", STR_PAD_LEFT);
        }
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <form action="" method="post">
            <div class="logo">
                <div class="logo_word">
                    <img src="images/200px-Myanma_Railway.svg.png" height="90px">
                </div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php" style="color: #0099cc;">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
            <div class="above">
                <div class="Login">
                    <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Carriage</span>
                </div>
                <div class="box">
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Carriage ID</span> <input type="text"  readonly name="carriageid" class="log-text" value="<?php echo $carriageid; ?>">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Seat Type</span>
                        <select name="seattypeid"  class="log-text" required>
                            <option value="">Select Seat Type</option>
                            <?php
                                $result = mysqli_query($connection, "SELECT seattypeid,seattypename FROM seattype");
                                while($row = mysqli_fetch_array($result)) {
                                    $sta = ($seattypeid== $row[0])? "selected": "";
                            ?>
                            <option value="<?php echo $row[0]; ?>" <?php echo $sta; ?>><?php echo $row[1]; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Total Seat</span> <input type="text" name="totalseat" class="log-text" value="<?php echo $totalseat; ?>" required maxlength="10" pattern="[0-9]+">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Seat Per Row</span> <input type="text" name="seatperrow" class="log-text" value="<?php echo $seatperrow; ?>" required maxlength="10" pattern="[0-9]+">
                    </div>
                    <div>
                        <input type="submit" name="register-carriage" value="<?php echo isset($_GET["updateid"])? 'Update': 'Register'; ?>" width="400px" class="but">
                        <input type="submit" name="cancel-carriage" value="Cancel" width="400px" class="but" formnovalidate>
                    </div>
                </div>
        
                <table border="4" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top:30px; color:#DA70D6; margin-bottom: 30px;" >
                    <tr bgcolor="cyan" style="color:#DA70D6;">
                        <th>Carriage ID</th>
                        <th>Seat Type</th>
                        <th>Total Seat</th>
                        <th>Seat Per Row</th>
                        <th></th>
                        <th></th>
                    </tr>
                    <?php
                        $result = mysqli_query($connection, "SELECT * FROM carriage c, seattype s WHERE c.seattypeid = s.seattypeid ORDER BY carriageid");
                        while($row = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row[0]; ?></td>
                        <td><?php echo $row[5]; ?></td>
                        <td><?php echo $row[2]; ?></td>
                        <td><?php echo $row[3]; ?></td>
                        <td><a href="registercarriage.php?updateid=<?php echo $row[0]; ?>">Update</a></td>
                        <td><a href="registercarriage.php?deleteid=<?php echo $row[0]; ?>" onclick="return confirm('Are you sure to delete?');">Delete</a></td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </form>
    </body>
</html>
