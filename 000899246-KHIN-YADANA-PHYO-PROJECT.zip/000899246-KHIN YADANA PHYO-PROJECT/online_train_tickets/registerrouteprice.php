<?php
    session_start();
    include "./mysql_connect.php";

    if(!isset($_SESSION["staffid"])) {
        echo "<script>alert('Please log in to access this file.'); location.assign('login.php');</script>";
    }
    if($_SESSION["staffrole"] != "Admin") {
        echo "<script>alert('You can\'t access this file.'); location.assign('login.php');</script>";
    }
    
    $routeid ="";
    $seattypeid = "";
    $price = "";
    
    if(isset($_POST["register-routeprice"])) {
        $routeid = $_POST["routeid"];
        $seattypeid = $_POST["seattypeid"];
        $price = $_POST["price"];
        
        if(!isset($_GET["updaterouteid"])) {
            $result = mysqli_query($connection, "SELECT * FROM routeprice WHERE routeid = '$routeid' AND seattypeid = '$seattypeid'");
            if($row = mysqli_fetch_assoc($result)) {
                echo "<script>alert('Route and Seat Type already exists. Change another route.');</script>";
            }
            else {
                $result = mysqli_query($connection, "INSERT INTO routeprice VALUES('$routeid', '$seattypeid', $price)");

                if($result) {
                    echo "<script>alert('Successful Register.'); location.assign('registerrouteprice.php');</script>";
                }
                else {
                    echo "<script>alert('Error in register.');</script>";
                }
            }
        }
        else {
            $oldrouteid = $_GET["updaterouteid"];
            $oldseattypeid = $_GET["updateseattypeid"];
            $result = mysqli_query($connection, "SELECT * FROM routeprice WHERE (routeid != '$oldrouteid' AND seattypeid != '$oldseattypeid') AND (routeid != '$routeid' AND seattypeid != '$seattypeid')");
            if($row = mysqli_fetch_array($result)) {
                echo "<script>alert('Route and Seat Type already exists. Change another route.');</script>";
            }
            else {
                $result = mysqli_query($connection, "UPDATE routeprice SET routeid = '$routeid', seattypeid = '$seattypeid', price = $price WHERE routeid = '$routeid' AND seattypeid = '$seattypeid'");
                if($result) {
                    echo "<script>alert('Successful Update.'); location.assign('registerrouteprice.php');</script>";
                }
                else {
                    echo "<script>alert('Error in register.');</script>";
                }
            }
        }
    }
     
    if(isset($_GET["updaterouteid"]) && isset($_GET["updateseattypeid"])) {
        $routeid = $_GET["updaterouteid"];
        $seattypeid = $_GET["updateseattypeid"];
        $result = mysqli_query($connection, "SELECT * FROM routeprice WHERE routeid = '$routeid' AND seattypeid = '$seattypeid'");
        $row = mysqli_fetch_array($result);
        $routeid = $row[0];
        $seattypeid = $row[1];
        $price = $row[2];
    }
    
    if(isset($_GET["deleterouteid"]) && isset($_GET["deleteseattypeid"])) {
        $routeid = $_GET["deleterouteid"];
        $seattypeid = $_GET["deleteseattypeid"];
        $result = mysqli_query($connection, "DELETE FROM routeprice WHERE routeid = '$routeid' AND seattypeid = '$seattypeid'");
        if($result) {
            echo "<script>alert('Successful Delete.'); location.assign('registerrouteprice.php');</script>";
        }
        else {
            echo "<script>alert('Your route price is used and can't delete.'); location.assign('registerrouteprice.php');</script>";
        }
    }
    
    if(isset($_POST["cancel-routeprice"])) {
        header("location: registerrouteprice.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <form action="" name="frm" method="post">
            <div class="logo">
                <div class="logo_word">
                    <img src="images/200px-Myanma_Railway.svg.png" height="90px">
                </div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php" style="color: #0099cc;">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
            <div class="above">
                <div class="Login">
                    <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Route Price</span>
                </div>
                <div class="box" style="height: 380px;">
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Route</span>
                        <select name="routeid"  class="log-text" required>
                            <option value="">Select Route</option>
                            <?php
                                $result = mysqli_query($connection, "SELECT r.routeid, f.stationname, t.stationname FROM route r, (SELECT routeid, stationname FROM route r, station s WHERE r.fromstation = s.stationid) f, (SELECT routeid, stationname FROM route r, station s WHERE r.tostation = s.stationid) t WHERE r.routeid = f.routeid AND r.routeid = t.routeid ORDER BY routeid");
                                while($row = mysqli_fetch_array($result)) {
                                    $rsel = ($routeid == $row[0])? "selected": "";
                            ?>
                            <option value="<?php echo $row[0]; ?>" <?php echo $rsel; ?>><?php echo $row[1]; ?>&nbsp;-&nbsp;<?php echo $row[2]; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Seat Type</span>
                        <select name="seattypeid"  class="log-text" required>
                            <option value="">Select Seat Type</option>
                            <?php
                                $result = mysqli_query($connection, "SELECT seattypeid,seattypename FROM seattype");
                                while($row = mysqli_fetch_array($result)) {
                                    $sta = ($seattypeid == $row[0])? "selected": "";
                            ?>
                            <option value="<?php echo $row[0]; ?>" <?php echo $sta; ?>><?php echo $row[1]; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:orange; font-size:21px;">Price</span> <input type="text" name="price" class="log-text" value="<?php echo $price; ?>" required maxlength="8" pattern="[0-9]*[.]?[0-9]+">
                    </div>
                    <div>
                        <input type="submit" name="register-routeprice" value="<?php echo isset($_GET["updaterouteid"])? 'Update': 'Register'; ?>" width="400px" class="but">
                        <input type="submit" name="cancel-routeprice" value="Cancel" width="400px" class="but" formnovalidate>
                    </div>
                </div>
        
                <table border="4" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top:30px; color:#DA70D6; margin-bottom: 30px;" >
                    <tr bgcolor="cyan" style="color:#DA70D6;">
                        <th>Route ID</th>
                        <th>From Station</th>
                        <th>To Station</th>
                        <th>Seat Type ID</th>
                        <th>Seat Type</th>
                        <th>Price</th>
                        <th></th>
                        <th></th>
                    </tr>
                    <?php
                        $result = mysqli_query($connection, "SELECT rp.routeid, f.stationname, t.stationname, rp.seattypeid, s.seattypename, rp.price FROM route r, routeprice rp, seattype s, (SELECT routeid, stationname FROM route r, station s WHERE r.fromstation = s.stationid) f, (SELECT routeid, stationname FROM route r, station s WHERE r.tostation = s.stationid) t WHERE r.routeid = f.routeid AND r.routeid = t.routeid AND r.routeid = rp.routeid AND rp.seattypeid = s.seattypeid ORDER BY rp.routeid");
                        while($row = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row[0]; ?></td>
                        <td><?php echo $row[1]; ?></td>
                        <td><?php echo $row[2]; ?></td>
                        <td><?php echo $row[3]; ?></td>
                        <td><?php echo $row[4]; ?></td>
                        <td><?php echo $row[5]; ?></td>
                        <td><a href="registerrouteprice.php?updaterouteid=<?php echo $row[0]; ?>&updateseattypeid=<?php echo $row[3]; ?>">Update</a></td>
                        <td><a href="registerrouteprice.php?deleterouteid=<?php echo $row[0]; ?>&deleteseattypeid=<?php echo $row[3]; ?>" onclick="return confirm('Are you sure to delete?');">Delete</a></td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </form>
    </body>
</html>
