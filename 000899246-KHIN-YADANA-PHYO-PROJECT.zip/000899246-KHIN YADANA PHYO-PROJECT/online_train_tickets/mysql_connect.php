<?php
    $host = "localhost";
    $user = "root";
    $pword = "";
    $database = "online_train_tickets";
    $port = "3306";
    
    $connection  = new mysqli($host, $user, $pword, $database, $port); 
        
    if ($connection->connect_error) {
        trigger_error("Failed to connect to MySQL : " . $connection->connect_error, E_USER_ERROR);
    }
 ?>
    
    
