<?php
    session_start();
    include "./mysql_connect.php";
 
    $customerid= (isset($_SESSION['customerid']))? $_SESSION['customerid']: "";
    $fromstation = (isset($_POST["fromstation"]))? $_POST["fromstation"]: "";
    $tostation = (isset($_POST["tostation"]))? $_POST["tostation"]: "";
    $depaturedate = (isset($_POST["depaturedate"]))? $_POST["depaturedate"]: "";
      
    $_SESSION['fromstation'] = $fromstation;
    $_SESSION['tostation'] = $tostation;
    $_SESSION['depaturedate'] = $depaturedate;
?>

<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
        
        <link rel="stylesheet" href="js/Datepicker/themes/ui-lightness/jquery.ui.all.css">
        <script src="js/jquery-2.1.1.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.core.min.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.datepicker.min.js"></script>
    </head>

    <script>
        $(function() {
            $("#depaturedate").datepicker();
            $("#depaturedate").datepicker("option", "dateFormat", "yy-mm-dd");
            $("#depaturedate").datepicker("option", "minDate", "+1");
            $("#depaturedate").datepicker("option", "changeMonth", true);
            $("#depaturedate").datepicker("option", "changeYear", true);
            $("#depaturedate").datepicker("setDate", "<?php echo $depaturedate; ?>");
        });
    </script>

    <body>
        <form name="sch" method="post">
            <div class="logo">
                <div class="logo_word">
                    <img src="images/200px-Myanma_Railway.svg.png" height="90px">
                </div>
                <div class="button">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <?php if(isset($_SESSION['customerid'])) { ?>
                        <li><a href="editcustomer.php">Account</a></li>
                        <li><a href="search.php">Search</a></li>
                        <li><a href="booking.php">Booking</a></li>
                        <li><a href="logout.php">Logout</a></li>
                        <?php } else { ?>
                        <li><a href="registercustomer.php">Register</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="search.php">Search</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>

            <div class="movie">
                <video src="myanmar.mp4" controls   width="500px" height="300px"></video>
            </div>

            <div class="schedule" style="margin-top:150px;">
                <span class="sch-word"><u>SCHEDULE</u></span>
                <?php if(isset($_SESSION['customername'])) { ?> 
                <p class="login-word"><marquee direction="left">Welcome <?php echo $_SESSION['customername'] ?></marquee></p>
                <?php }else {?> 
                     <p class="login-word"><marquee direction="left">Welcome Customer</marquee></p>    
                <?php } ?>    
            </div>
            <div class="Login">
                <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Choose Schedule</span>
            </div>
            <div class="box">    
                <div class="nn">
                    <span style="font-family:Cooper; color:orange; font-size:21px;">From Station</span>
                    <select name="fromstation">
                        <option value="">Select station</option>
                        <?php
                            $result = mysqli_query($connection, "SELECT stationid,stationname FROM station");
                            while($row = mysqli_fetch_array($result)) {
                                $fst = ($fromstation == $row[0])? "selected": "";
                        ?>
                        <option value="<?php echo $row[0]; ?>" <?php echo $fst; ?>><?php echo $row[1]; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="nn">
                    <span style="font-family:Cooper; color:orange; font-size:21px;">To Station</span>
                    <select name="tostation">
                        <option value="">Select station</option>
                        <?php
                            $result = mysqli_query($connection, "SELECT stationid,stationname FROM station");
                            while($row = mysqli_fetch_array($result)) {
                                $tst = ($tostation == $row[0])? "selected": "";
                        ?>
                        <option value="<?php echo $row[0] ?>" <?php echo $tst; ?>><?php echo $row[1]; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="nn">
                    <span style="font-family:Cooper; color:orange; font-size:21px;">Depature Date</span>
                    <input type="text" name="depaturedate" id="depaturedate" value="" style="width: 147px; height: 25px;"  />
                    <input type="button" value="Clear" name="clear" onclick="document.sch.depaturedate.value=''; submit();" style="height: 33px; margin-left: -10px;" />
                </div>
                <br/>
                <div class="nn">
                    <input type="submit" name="search" value="SEAECH SCHEDULE" style="border: 2px dotted pink; color: white; background: #FF1493;  "/>
                </div>
            </div>
            <div  class="table">        
                <table border="3"  class="table-design" width="200px" height="150px">
                    <tr>
                        <td colspan="4">Yangon-Mandalay</td>
                    </tr>
                    <tr>
                        <th>TrainName</th>
                        <th>DepatureDate</th>
                        <th>DepatureTime</th>                
                    </tr>
                    <?php
                        if(isset($_POST["search"])) {
                            $result = mysqli_query($connection, "Select Distinct t.trainname
                                                              ,      sch.depaturedate
                                                              ,      sch.departuretime
                                                              ,      sch.scheduleid
                                                              ,      schs.depaturestatus
                                                              ,      t.trainid
                                                              from   train as t
                                                              ,      schedule as sch
                                                              ,      schedulestation as schs
                                                              ,      station as st
                                                              ,      scheduledetail as schd
                                                              ,      route as r
                                                              where  t.trainid      = sch.trainid
                                                              and    sch.scheduleid = schs.scheduleid
                                                              and    schs.stationid = st.stationid
                                                              and    schd.routeid   = r.routeid
                                                              and    fromstation = '$fromstation'
                                                              and    tostation= '$tostation'
                                                              and    depaturedate='$depaturedate';
                                                              ");

                            while ($r = mysqli_fetch_array($result)) {
                    ?>
                    <tr>
                        <td><?php echo $r[0]; ?></td><td><?php echo $r[1]; ?></td><td><?php echo $r[2]; ?></td>
                        <td>
                            <?php if($r[4] == 0) { ?>
                                <?php if(isset($_SESSION['customername'])){ ?> 
                            <a href="seat.php?scheduleid=<?php echo $r[3]; ?>">Booking</a>
                            <?php } else {?> 
                            <a href="login.php?scheduleid=<?php echo $r[3]; ?>">Log In</a>   
                            <?php } ?>
                            <?php } else { ?>
                            Already Departed
                            <?php } ?>
                        </td>
                    </tr>          
                    <?php } 
                            $rowcount = mysqli_num_rows($result);
                        }
                    ?>
                </table>
            </div>
        </form>
        <div>
            <?php if($customerid)  { ?>
            <table border="4" bordercolor="yellow" width="90%" bgcolor="#E2C4AA" style="margin-top:30px; color:yellow; margin:0 auto; " >
                <tr><th colspan="12"><marquee direction="left"> The Tickets that confirmed by Staff</marquee></th> </tr>
                <tr bgcolor="cyan" style="color:#FF1493;">
                    <th>ID Number</th>
                    <th>Traveller</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Price</th>
                    <th>Seat</th>
                    <th>Carriage</th>
                    <th>Seat Type</th>
                    <th>Train</th>
                    <th>Trip</th>
                    <th>For Date</th>
                    <th>For Time</th>
                </tr>
                <?php 
                    $result = mysqli_query($connection, "select   tic.idnumber
                                                            ,        tic.travellername
                                                            ,        fstat.stationname
                                                            ,        tstat.stationname
                                                            ,        price
                                                            ,        seatno
                                                            ,        carriageserialno
                                                            ,        seattypename
                                                            ,        trainname
                                                            ,        tripname
                                                            ,        depaturedate
                                                            ,        departuretime
                                                            ,        tic.ticketid
                                                            From     ticket as tic
                                                            ,        booking as boo
                                                            ,        customer as cus
                                                            ,        payment as pay
                                                            ,        route as rou
                                                            ,        schedule as sch
                                                            ,        schedulecarriage as schcar
                                                            ,        scheduledetail as schd
                                                            ,        train as t
                                                            ,        routeprice as roup
                                                            ,        seattype as sea
                                                            ,        carriage as car
                                                            ,        (SELECT routeid, stationname FROM route r, station s
                                                                      WHERE r.fromstation = s.stationid) as fstat
                                                            ,        (SELECT routeid, stationname FROM route r, station s
                                                                      WHERE r.tostation = s.stationid) as tstat
                                                            Where    tic.bookingid = boo.bookingid
                                                            and      cus.custommerid = boo.customerid
                                                            and      boo.bookingid = pay.bookingid
                                                            and      tic.routeid = rou.routeid
                                                            and      tic.schedulecarriageid = schd.schedulecarriageid
                                                            and      schd.routeid = tic.routeid
                                                            and      tic.schedulecarriageid = schcar.schedulecarriageid
                                                            and      schcar.scheduleid = sch.scheduleid
                                                            and      sch.trainid = t.trainid
                                                            and      tic.routeid = roup.routeid
                                                            and      schcar.carriageid = car.carriageid
                                                            and      car.seattypeid = roup.seattypeid
                                                            and      car.seattypeid = sea.seattypeid
                                                            and      rou.routeid = fstat.routeid
                                                            and      rou.routeid = tstat.routeid
                                                            and      cus.custommerid = '$customerid'
                                                            and      sch.depaturedate > curdate();"); 
                    while($row = mysqli_fetch_array($result)) { 
                ?>
                <tr>
                    <td><?php echo $row[0]; ?></td>
                    <td><?php echo $row[1]; ?></td>
                    <td><?php echo $row[2]; ?></td>
                    <td><?php echo $row[3]; ?></td>
                    <td><?php echo $row[4]; ?></td>
                    <td><?php echo $row[5]; ?></td>
                    <td><?php echo $row[6]; ?></td>
                    <td><?php echo $row[7]; ?></td>
                    <td><?php echo $row[8]; ?></td>
                    <td><?php echo $row[9]; ?></td>
                    <td><?php echo $row[10]; ?></td>
                    <td><?php echo $row[11]; ?></td>
                    <td><a href="ticketprint.php?tid=<?php echo $row[12]; ?>">Print</a></td>
                </tr>
                <?php } ?>
            </table>
            <?php } ?>
        </div>   
    </body>
</html>