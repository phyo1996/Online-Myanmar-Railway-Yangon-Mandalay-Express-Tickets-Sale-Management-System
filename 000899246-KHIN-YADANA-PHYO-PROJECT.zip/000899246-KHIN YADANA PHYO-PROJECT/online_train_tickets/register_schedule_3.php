<?php
    session_start();
    include "./mysql_connect.php";
    
    if(isset($_POST['draw']))
    {
        $candraw = false;
        $result = mysqli_query($connection, "SELECT routeid FROM route");
        while($row = mysqli_fetch_array($result)) {
            if(!empty($_POST[$row[0]])) {
                $candraw = true;
            }
        }
        if($candraw) {
            $temp = split(",", $_SESSION["registertrain"]);
            $result1 = mysqli_query($connection, "INSERT INTO schedule VALUES('$temp[0]', curdate(), '$temp[1]', '$temp[2]', '$temp[3]')");
            if($result1) {
                foreach ($_SESSION["carriages"] as $key => $value) {
                    $result2 = mysqli_query($connection, "SELECT MAX(schedulecarriageid) FROM schedulecarriage");
                    $scar = "Scar0001";
                    if($row = mysqli_fetch_assoc($result2)) {
                        $maxid = $row["MAX(schedulecarriageid)"];
                        $newid = substr($maxid, 4) + 1;
                        $scar = "Scar".str_pad($newid, 4, "0", STR_PAD_LEFT);
                    }
                    $tempdetail = split("-", $value);
                    $result3 = mysqli_query($connection, "INSERT INTO schedulecarriage VALUES('$scar', '$temp[0]', '$tempdetail[0]', '$key')");

                    $seat = array();
                    $result4 = mysqli_query($connection, "SELECT routeid FROM route");
                    while($row = mysqli_fetch_array($result4)) {
                        if(!empty($_POST[$row[0]])) {
                            $s = substr($_POST[$row[0]], 0, strlen($_POST[$row[0]]) - 1);
                            $t = split("#", $s);
                            foreach ($t as $key1 => $value1) {
                                $seat[$row[0]][$key1] = $value1;
                            }

                            $result6 = mysqli_query($connection, "SELECT tostation, ADDTIME(ADDTIME(travellingtime, restingtime), '$temp[2]') FROM route WHERE routeid = '$row[0]'");
                            $row1 = mysqli_fetch_array($result6);
                            $result7 = mysqli_query($connection, "INSERT INTO schedulestation(scheduleid,stationid,proposeddepaturetime) VALUES('$temp[0]', '$row1[0]', '$row1[1]')");
                        }
                    }
                    $carriageserialno = $key;
                    foreach ($seat as $rid => $id_carriage_seat) {
                        $seatno = "";
                        foreach ($id_carriage_seat as $carriage_seat) {
                            $car = split("-", $carriage_seat);
                            if($car[0] == $carriageserialno) {
                                $seatno .= $car[1] . "#";
                            }
                        }
                        if(!empty($seatno)) {
                            $seatno = substr($seatno, 0, strlen($seatno) - 1);
                            $result5 = mysqli_query($connection, "INSERT INTO scheduledetail VALUES('$scar', '$rid', '$seatno')");
                        }
                    }
                    
                    
                }
                
                $result8 = mysqli_query($connection, "SELECT trainname,departuretime FROM train t, schedule s WHERE t.trainid = s.trainid AND s.scheduleid = '$temp[0]' AND t.trainid = '$temp[3]'");
                $row2 = mysqli_fetch_array($result8);
                if(stristr($row2[0], 'u')) {
                    $result9 = mysqli_query($connection, "SELECT stationid FROM station WHERE stationname = 'Yangon'");
                    $row3 = mysqli_fetch_array($result9);
                    $result10 = mysqli_query($connection, "INSERT INTO schedulestation(scheduleid,stationid,proposeddepaturetime) VALUES('$temp[0]', '$row3[0]', '$row2[1]')");
                }
                else {
                    $result9 = mysqli_query($connection, "SELECT stationid FROM station WHERE stationname = 'Mandalay'");
                    $row3 = mysqli_fetch_array($result9);
                    $result10 = mysqli_query($connection, "INSERT INTO schedulestation(scheduleid,stationid,proposeddepaturetime) VALUES('$temp[0]', '$row3[0]', '$row2[1]')");
                }
                unset($_SESSION["registertrain"]);
                unset($_SESSION["carriages"]);
                echo "<script>alert('Successful draw schedule');location.assign('register_schedule_1.php');</script>";
            }
            else {
                echo "<script>alert('Error on schedule save');</script>";
            }
        }
        else {
            echo "<script>alert('Please choose seat to draw schedule');</script>";
        }
    }
?>
<html>                        
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
        <script>
            function saveSeatNo(serialno, seatno) {
                var route = document.getElementById("route");
                var routeid = route.options[route.selectedIndex].value;
                var routename = route.options[route.selectedIndex].text;
                var color = route.options[route.selectedIndex].style.backgroundColor;
                var btnbackcolor = document.getElementById(serialno + "-" + seatno).style.backgroundColor;
                if(btnbackcolor !== "rgb(255, 255, 255)") {
                    var output = confirm("Previous select. Do you want to change?");
                    if(output === true) {
                        for(var i = 0; i < route.options.length; i++) {
                            var val = route.options[i].value;
                            var vals = document.getElementById(val).value.split("#");
                            var temp = "";
                            for(var j = 0; j < vals.length; j++) {
                                if(vals[j] !== serialno + "-" + seatno) {
                                    temp += vals[j] + "#";
                                }
                            }
                            if(temp === "#") temp = "";
                            if(temp.endsWith("##")) temp = temp.substring(0, temp.length - 1);
                            document.getElementById(val).value = temp;
                        }
                        document.getElementById(serialno + "-" + seatno).style.backgroundColor = color;
                        var temp = document.getElementById(routeid).value;
                        document.getElementById(routeid).value = temp + serialno + "-" + seatno + "#";
                    }
                }
                else {
                    document.getElementById(serialno + "-" + seatno).style.backgroundColor = color;
                    var temp = document.getElementById(routeid).value;
                    document.getElementById(routeid).value = temp + serialno + "-" + seatno + "#";
                }
            }
        </script>
    </head>

    <body>
        <form action="" method="post">
            <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php" style="color: #0099cc;">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
            <div class="above" style="height: 1050px;">
                <div class="Login" style="width: 800px;">
                    <span class="Login-word" style="margin-left:270px; font-size:31px; font-weight:bold;">Seat Detail Entry</span>
                </div>
                <div class="nn">
                    <span style="font-family:Cooper; color:orange; font-size:21px;">Route</span>
                    <select name="route" id="route"  class="log-text" required>
                        <?php
                            $result = mysqli_query($connection, "SELECT r.routeid, f.stationname, t.stationname FROM route r, (SELECT routeid, stationname FROM route r, station s WHERE r.fromstation = s.stationid) f, (SELECT routeid, stationname FROM route r, station s WHERE r.tostation = s.stationid) t WHERE r.routeid = f.routeid AND r.routeid = t.routeid ORDER BY routeid");
                            while($row = mysqli_fetch_array($result)) {
                                $color = dechex(rand(0x000000, 0xFFFFFF));
                        ?>
                        <option value="<?php echo $row[0]; ?>" style="background-color: <?php echo $color; ?>"><?php echo $row[1]; ?>&nbsp;-&nbsp;<?php echo $row[2]; ?></option>
                        <?php } ?>
                    </select>
                    <?php
                        $result = mysqli_query($connection, "SELECT r.routeid, f.stationname, t.stationname FROM route r, (SELECT routeid, stationname FROM route r, station s WHERE r.fromstation = s.stationid) f, (SELECT routeid, stationname FROM route r, station s WHERE r.tostation = s.stationid) t WHERE r.routeid = f.routeid AND r.routeid = t.routeid ORDER BY routeid");
                        while($row = mysqli_fetch_array($result)) {
                    ?>
                    <input type="hidden" name="<?php echo $row[0]; ?>" id="<?php echo $row[0]; ?>" value="" />
                    <?php } ?>
                    &nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="draw" value="Draw Schedule" />
                </div>
                
                <div class="box" style="width: 1050px; height: 870px; overflow: auto; margin-bottom: 40px;">
                    <?php
                        foreach ($_SESSION["carriages"] as $key => $value) {
                            $temp = split("-", $value);
                    ?>
                    <div class="class" style="border: 2px dashed fuchsia; border-radius:10px; padding-left: 20px; height: auto;">
                        <div style="font-size: 16px; background-color: #87f0f0; text-align: center; border-top-left-radius: 10px; border-top-right-radius: 10px; margin-left: -20px;">Carriage No. : <?php echo $key; ?> , Class : <?php echo $temp[2]; ?></div>
                        <?php
                            $result = mysqli_query($connection, "SELECT totalseat,seatperrow FROM carriage WHERE carriageid = '$temp[0]'");
                            $row = mysqli_fetch_array($result);
                            $totalseat = $row[0];
                            $seatperrow = $row[1];

                            $no = 1;
                            for($i = 0; $i < $totalseat; $i+=$seatperrow) {
                                for($j = 0; $j < $seatperrow; $j++) {
                                    if($seatperrow == 2) {
                                        echo "<input type='button' id='$key-$no' value='$no' class='seatbutton' style='background-color:#FFFFFF; margin-right:30px;width: 100px;' onclick='saveSeatNo($key, this.value);'/>";
                                    }
                                    else if($seatperrow == 3) {
                                        echo "<input type='button' name='seatno' value='$no' class='seatbutton' style='background-color:#FFFFFF; margin-right:42px;' onclick='saveSeatNo($key, this.value);'/>";
                                    }
                                    else {
                                        echo "<input type='button' id='$key-$no' value='$no' class='seatbutton' style='background-color:#FFFFFF; margin-right:10px;' onclick='saveSeatNo($key, this.value);'/>";
                                    }
                                    $no++;
                                }
                                echo "<br>";
                            }
                        ?>
                    </div>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </form>
    </body>
</html>
