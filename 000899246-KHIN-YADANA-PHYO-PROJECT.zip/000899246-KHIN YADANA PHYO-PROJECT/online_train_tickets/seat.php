<?php
session_start();
include "./mysql_connect.php";

if(!isset($_POST["seattype"])) {
    $_SESSION["searchseat"] = 0;    
}
else {
    $_SESSION["searchseat"] = $_POST["seattype"];    
}

if(isset($_POST["seatno"])) {
    $tempseatno = array_pop(array_keys($_POST["seatno"]));
    $no = isset($_SESSION["userseat"])? sizeof($_SESSION["userseat"]): 0;
//    echo "<script>alert('$no');</script>";
    $no++;
    $temp = $_GET["scheduleid"] . "," . $_SESSION["fromstation"] . "," . $_SESSION["tostation"] . "," . $_SESSION["depaturedate"] . "," . $_POST["seattype"] . "," .$tempseatno;
    $_SESSION["userseat"][$no] = $temp;
}

if(isset($_POST["book"])) {
    header("Location: booking.php");
}                                                                                                         
?> 
 
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
     </script>
        
        <link rel="stylesheet" href="js/Datepicker/themes/ui-lightness/jquery.ui.all.css">
        <script src="js/jquery-2.1.1.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.core.min.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.datepicker.min.js"></script>
</head>

<body>
<form name="sch" method="post">
    <div class="logo">
        <div class="logo_word">
            <img src="images/200px-Myanma_Railway.svg.png" height="90px">
            </div>
        <div class="button">
        <ul>
            <li>
            <a href="index.php">Home</a>    
            </li>
                    <?php if(isset($_SESSION['customername']))
                     { ?>
                    <li><a href="search.php">Schedule</a></li>
                    <li><a href="ticket.php">Ticket</a></li>
                    <li><a href="logout.php">Logout</a></li>
                    <?php } else {?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                    <?php } ?>
            <li>
            <a href="expresso.html">Contanct</a>    
            </li>
        </ul>
</div>
    </div>
        
        <div class="movie">
            <video src="myanmar.mp4" controls   width="500px" height="300px"></video>
        </div>
        <div class="schedule" style="margin-top:150px;">
            <span class="sch-word"><u>SEAT</u></span>
            <p class="login-word"><marquee direction="left">Welcome <?php echo $_SESSION['customername'] ?></marquee></p>
        </div>
        <div class="above" style="height:1000px;">
        <div class="nn">
                                  <span style="font-family:Cooper; color:orange; font-size:18px;">Seat Type</span><select name="seattype">
                                    <option value="">Select SEATTYPE</option>
                                    <?php
                                        $result = mysqli_query($connection, "SELECT seattypename FROM seattype");
                                        while($row = mysqli_fetch_array($result)) {
                                            $st = ($_SESSION['searchseat'] == $row[0])? "selected": "";
                                    ?>
                                    <option value="<?php echo $row[0]; ?>" <?php echo $st; ?>><?php echo $row[0]; ?></option>
                                    <?php } ?>
                                    </select>
                                    <input type="submit" name="search_seat" value="SEARCH SEAT" style="width:105px;"/>
            </div>
            <div class="nn">
            <input type="submit" name="book" value="BOOK Your Seat Here" style="width:200px;"/> 
            </div>
        
        
        
        <div class="carriageholder">
        <?php
        if(isset($_POST["seattype"])) {
    $fromstation = (isset($_SESSION["fromstation"]))? $_SESSION["fromstation"]: "";
    $tostation = (isset($_SESSION["tostation"]))? $_SESSION["tostation"]: "";
    $depaturedate = (isset($_SESSION["depaturedate"]))? $_SESSION["depaturedate"]: "";
    $class    =(isset($_POST["seattype"]))?$_POST["seattype"]:"";
    $_SESSION['seattype'] = $class;
    $_SESSION['searchseat']= $_POST['seattype'];
     


      $orderedseat = array();
                        $result = mysqli_query($connection, "select   schcar.carriageserialno
                                                            ,        tic.seatno
                                                            From     schedule as sch
                                                            ,        schedulecarriage as schcar
                                                            ,        scheduledetail as schd
                                                            ,        ticket as tic
                                                            ,        route as rou
                                                            Where    sch.scheduleid  =  schcar.scheduleid
                                                            and      schcar.schedulecarriageid = schd.schedulecarriageid
                                                            and      schd.schedulecarriageid = tic.schedulecarriageid
                                                            and      schd.routeid = rou.routeid
                                                            and      sch.depaturedate = '$depaturedate'
                                                            and      rou.fromstation='$fromstation'
                                                            and      rou.tostation='$tostation';
                                                              ");
                        $numrow = mysqli_num_rows($result);
                        for($i = 0; $i < $numrow; $i++) {
                            $row = mysqli_fetch_array($result);
                            $orderedseat[$i] = $row[0] . "," . $row[1];
                        }
                        
                        $result = mysqli_query($connection, " select     schd.seatnumbers
                                                            ,          schd.routeid
                                                            ,          car.totalseat
                                                            ,          seatperrow
                                                            ,          carriageserialno
                                                            ,          st.seattypename
                                                            ,          schcar.schedulecarriageid
                                                            From       train as t
                                                            ,          schedule as sch
                                                            ,          schedulecarriage as schcar
                                                            ,          route as rou
                                                            ,          scheduledetail as schd
                                                            ,          carriage as car
                                                            ,          seattype as st
                                                            where      t.trainid = sch.trainid
                                                            and        sch.scheduleid = schcar.scheduleid
                                                            and        schcar.schedulecarriageid = schd.schedulecarriageid
                                                            and        schd.routeid = rou.routeid
                                                            and        schcar.carriageid = car.carriageid
                                                            and        car.seattypeid    = st.seattypeid
                                                            and        fromstation ='$fromstation'
                                                            and        tostation   ='$tostation'
                                                            and        seattypename='$class'
                                                            and        sch.depaturedate='$depaturedate';
                                                            ");
                        
                        $seatindexnumber = 0;
                        while($row = mysqli_fetch_array($result)) {
                    ?>
                    <div class="class" style="border: 2px dashed fuchsia; border_radius:100px;">
                        <div style="font-size: 16px; background-color: #87f0f0;"> Carriage No. : <?php echo $row[4]; ?> , Class : <?php echo $row[5]; ?></div>
                    <?php
                    //0=seatnumbers, 1=#, 1(2)=routeid, 2(3)=totalseat, 3(4)=seatperrow, 4(5)=serialno, 5(6)=seattypename, 6(7)=schedulecarriageid
                        $s = split("#", $row[0]);
                        for($seatno = 1; $seatno <= $row[2]; $seatno++) {
                            //echo $s;
                            if(in_array($seatno, $s)) {
                                $tempseatno = $row[4] . "," . $seatno;
                                //print_r($orderedseat);
                                //$s = sizeof($orderseat);
                                //echo "<div style='color: white;'>$s</div>";
                                if(in_array($tempseatno, $orderedseat)) {
                    ?>
                    <input type="button" name="seatno[<?php echo $row[1] . ',' . $row[6] . ',' . $row[4] . ',' . $seatno; ?>]" value="<?php echo $seatno; ?>" class="seatbutton" style="background-color:maroon; color:cyan;"/>
                    <?php } else {
                        
                            $temps =$_GET["scheduleid"] . "," . $_SESSION["fromstation"] . "," . $_SESSION["tostation"] . "," . $_SESSION["depaturedate"] . "," . $_POST["seattype"] . "," . $row[1] . ',' . $row[6] . ',' . $row[4] . ',' . $seatno;
                            if(isset($_SESSION["userseat"])) {
                                if(in_array($temps, $_SESSION["userseat"])) { ?>
                                    <input type="button" name="seatno[<?php echo $row[1] . ',' . $row[6] . ',' . $row[4] . ',' . $seatno; ?>]" value="<?php echo $seatno; ?>" class="seatbutton" style="background-color:yellow;"/>
                    <?php      }
                                else {
                                    ?>
                                    <input type="submit" name="seatno[<?php echo $row[1] . ',' . $row[6] . ',' . $row[4] . ',' . $seatno; ?>]" value="<?php echo $seatno; ?>" class="seatbutton" style="background:url(images/avaliable.JPG)"/>
                        <?php  }
                            }
                            else {?>
                                <input type="submit" name="seatno[<?php echo $row[1] . ',' . $row[6] . ',' . $row[4] . ',' . $seatno; ?>]" value="<?php echo $seatno; ?>" class="seatbutton" style="background:url(images/avaliable.JPG)"/>
                       <?php   }
                            } } else {?>
                    <input type="button" name="seatno[<?php echo $row[1] . ',' . $row[6] . ',' . $row[4] . ',' . $seatno; ?>]" value="<?php echo $seatno; ?>" class="seatbutton" disabled/>
                    <?php }
                        if(($row[3] == 2 && $seatno % $row[3] == 1) || ($row[3] == 4 && $seatno % $row[3] == 2)) {?>
                    <div class="middleline"></div>    
                    <?php } } ?>
                    </div>
                    <?php } } ?>
                    </div>
        </form>
        </div> 
</body>
</html>