<?php
    session_start();
    include("./mysql_connect.php");
    if(!isset($_SESSION["customerid"])) {
        echo "<script>alert('Please log in to update account.'); location.assign('login.php');</script>";
    }
    
    $customer_id=$_SESSION['customerid'];
    $customer_name=$_SESSION['customername'];
    $customer_contact_phone=$_SESSION['customercontactphone'];
    $customer_email=$_SESSION['email'];
     
    if(isset($_POST["update_customer"]))        
    {
        $customer_id = $_POST["customerid"];
        $customer_name = $_POST["customername"];
        $customer_contact_phone = $_POST["customercontanctphone"];
        $customer_email = $_POST["customeremail"];
        $customer_password =$_POST["customerpassword"];
        $customer_repassword =$_POST["customerrepassword"];
        
        $result = mysqli_query($connection, "SELECT email FROM customer WHERE email = '$customer_email' AND customerid != '$updateid' UNION SELECT email FROM staff WHERE email = '$customer_email'");
        if($row = mysqli_fetch_assoc($result)) {
            echo "<script>alert('Email already exists. Use another email address');</script>";
        }
        else {
            if(empty($updatepassword)) {
                $result = mysqli_query($connection, "UPDATE customer SET customername = '$customer_name', customercontactphone ='$customer_contact_phone',email='$customer_email' where custommerid='$customer_id'");
            
                if($result) {
                    $_SESSION['custommerid']=$customer_id;
                    $_SESSION['customername']=$customer_name;
                    $_SESSION['customercontactphone']=$customer_contact_phone;
                    $_SESSION['email']=$customer_email;
                    
                    echo "<script>alert('Success for your update.');</script>"; 
                }
                else {
                    echo "<script>alert('Error for your update.');</script>";
                }
            }
            else {
                if($customer_password != $customer_repassword) {
                    echo "<script>alert('Repassword must be same as Password.');</script>";
                }
                else {
                    $customer_password = password_hash($customer_password, PASSWORD_DEFAULT);
                    $result = mysqli_query($connection, "UPDATE customer SET customername = '$customer_name', customercontactphone ='$customer_contact_phone',email='$customer_email',password='$customer_password' where custommerid='$customer_id'");

                    if($result) {
                        $_SESSION['custommerid']=$customer_id;
                        $_SESSION['customername']=$customer_name;
                        $_SESSION['customercontactphone']=$customer_contact_phone;
                        $_SESSION['email']=$customer_email;

                        echo "<script>alert('Success for your update.');</script>"; 
                    }
                    else {
                        echo "<script>alert('Error for your update.');</script>";
                    }
                }
            }
        }
    }
    
    $view = 0;
    
    if(isset($_GET["update"])) {
        $view = 1;
    }
    
    if(isset($_POST["cancel_customer"])) {
        header("Location: editcustomer.php");
    }
    
    if(isset($_GET["delete"])) {
        $result = mysqli_query($connection, "DELETE FROM customer where custommerid='$customer_id'");

        if($result) {
            unset($_SESSION['custommerid']);
            unset($_SESSION['customername']);
            unset($_SESSION['customercontactphone']);
            unset($_SESSION['email']);

            echo "<script>alert('Success delete.'); location.assign('index.php');</script>"; 
        }
        else {
            echo "<script>alert('You can\'t delete your account.'); location.assign('editcustomer.php');</script>";
        }
    }
?>

<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <form action="" method="post">
            <div class="logo">
                <div class="logo_word">
                    <img src="images/200px-Myanma_Railway.svg.png" height="90px">
                </div>
                <div class="button">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="editcustomer.php">Account</a></li>
                        <li><a href="search.php">Search</a></li>
                        <li><a href="booking.php">Booking</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div><br/>
            </div>
            <div class="above">
                <div class="Login">
                    <span class="Login-word" style="margin-left:120px; font-size:31px; font-weight:bold;">Update Customer</span>
                </div>
                <div class="box" style="height:400px;">
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;">Customer ID</span> <input type="text" name="customerid" readonly class="log-text" value="<?php echo ($view==1)? $customer_id: ''; ?>"/>
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;">Name</span> <input type="text" name="customername"  required maxlength="25" pattern="[a-zA-Z][a-zA-Z0-9 .]+" class="log-text" value="<?php echo ($view==1)? $customer_name: ''; ?>">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;">Contact Phone</span> <input type="text" name="customercontanctphone" class="log-text" required maxlength="20" pattern="[0-9][0-9\- ]+" value="<?php echo ($view==1)? $customer_contact_phone: ''; ?>">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;"> Email</span> <input type="email" name="customeremail"  required maxlength="50" class="log-text" value="<?php echo ($view==1)? $customer_email: ''; ?>">
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;"> Password</span> <input type="password" name="customerpassword" class="log-text" maxlength="20" value="" >
                    </div>
                    <div class="nn">
                        <span style="font-family:Cooper; color:wheat; font-size:21px;"> Re-Password</span> <input type="password" name="customerrepassword" class="log-text" maxlength="20" value="">
                    </div>
                    <div>
                        <input type="submit" name="update_customer" value="Update" width="400px" class="but">
                        <input type="submit" name="cancel_customer" value="Cancel" width="400px" class="but" formnovalidate>
                    </div>
                </div><br/>
 
                <table border="4" bordercolor="yellow" bgcolor="maroon" width="100%" style="margin-top:30px; color:cyan;" >
                    <tr bgcolor="cyan" style="color:#FF1493;">
                        <th>Customer ID</th>
                        <th>Customer Name</th>
                        <th>Customer Contact Phone</th>
                        <th>Email</th> 
                        <th></th>
                        <th></th>
                    </tr>
                    <tr>
                        <td><?php echo $customer_id; ?></td>
                        <td><?php echo $customer_name; ?></td>
                        <td><?php echo $customer_contact_phone; ?></td>
                        <td><?php echo $customer_email; ?></td>  
                        <td><a href="editcustomer.php?update">To Update</a></td>
                        <td><a href="editcustomer.php?delete" onclick="return confirm('Are you sure to delete?');">Delete</a></td>
                    </tr>
                </table>
            </div>
        </form>
    </body>
</html>