<?php session_start(); ?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>
    <body>
        <div class="logo">
            <div class="logo_word">
                <img src="images/200px-Myanma_Railway.svg.png" height="90px">
            </div>
            <div class="button">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <?php if(isset($_SESSION['customerid'])) { ?>
                    <li><a href="editcustomer.php">Account</a></li>
                    <li><a href="search.php">Search</a></li>
                    <li><a href="booking.php">Booking</a></li>
                    <li><a href="logout.php">Logout</a></li>
                    <?php } else { ?>
                    <li><a href="registercustomer.php">Register</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="search.php">Search</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    <!-- <div class="container">
        <div class="header">
            <div class="header-left">
                <div class="header-img">
                <img src="./images/Big_train.gif" width="200px">
                </div>
            </div>
            <div class="header-right">
                <img src="./images/header.jpg" width="400px" height="290px">
            </div>
        </div>
        <div class="schedule">
            
        </div>    
    </div> -->


        <div class="above" style="height:700px;">
            <div class="welcome">
                <marquee direction="up" width="800px" height="70px">
                <marquee behaviour="scroll">
                WELCOME TO ONLINE MYANMAR RAILWAY</marquee></marquee>
            </div>
            <div class="pic-office">
                <img src="./images/bg.jpg" width="800px" height="400px;">
            </div>
        </div>
    </body>
</html>