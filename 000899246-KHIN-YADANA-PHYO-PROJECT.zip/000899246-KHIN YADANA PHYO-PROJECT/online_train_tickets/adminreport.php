<?php session_start(); ?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
</head>

<body>
<form action="" method="post" name="adminreport">
    <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php" style="color: #0099cc;">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
    <div class="above">
    <div class="reportheader " style="width: 300px;">
    <marquee direction="right" class="reportword">Online Myanmar Railway</marquee>
    </div>
        <div class="Login" style="height: 500px;">
            <a href="passengerlistreport.php"><span class="Login-word" style="margin-left:0px; font-size:15px; font-weight:bold;">Passenger List Report</span></a><br>
            <a href="dailyincomesalereport.php"><span class="Login-word" style="margin-left:0px; font-size:15px; font-weight:bold;">Daily Ticket Sale Report</span></a><br>
            <a href="remainticket.php"><span class="Login-word" style="margin-left:0px; font-size:15px; font-weight:bold;">Remain Ticket Report</span></a><br>
            <a href="unpaidticket.php"><span class="Login-word" style="margin-left:0px; font-size:15px; font-weight:bold;">Unpaid Ticket Report By Station</span></a>
        </div>
        
    </div>
    </form>
</body>
</html>
