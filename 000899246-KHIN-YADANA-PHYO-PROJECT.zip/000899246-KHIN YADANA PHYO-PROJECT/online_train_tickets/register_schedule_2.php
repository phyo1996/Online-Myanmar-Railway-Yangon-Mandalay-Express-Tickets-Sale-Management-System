<?php
    session_start();
    include "./mysql_connect.php";
    
    if(isset($_POST["add"])) {
        $_SESSION["carriages"][$_POST["serialno"]] = $_POST["carriage"];
    }
    
    if(isset($_POST["remove"])) {
        $id = array_pop(array_keys($_POST["remove"]));
        unset($_SESSION["carriages"][$id]);
    }
    
    if(isset($_POST["save"])) {
        echo "<script>alert('successful registeration.');location.assign('register_schedule_3.php')</script>";
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="./css/style.css">
    </head>

    <body>
        <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php" style="color: #0099cc;">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
        <div class="above">
            <div class="Login" style="width: 440px;">
                <span class="Login-word" style="margin-left:90px; font-size:31px; font-weight:bold;">Carriage Selection</span>
            </div>
            <div class="box" style="height: auto; width: 500px; margin-bottom: 40px;">
                <form action="" method="post">
                    <table border="4" bordercolor="yellow" bgcolor="maroon" width="100%" style="margin-top:30px; color:cyan;" >
                        <tr bgcolor="cyan" style="color:#FF1493;">
                            <th>Select Carriage</th>
                            <th>Carriage Serial No</th>                                  
                        </tr>
                        <?php
                            if(isset($_SESSION["carriages"])) {
                                foreach ($_SESSION["carriages"] as $key => $value) {
                                    $temp = split("-", $value);
                                    echo "<tr><td>$temp[1] - $temp[2]</td>"
                                        . "<td style='text-align: center;'>$key</td>"
                                        . "<td><input type='submit' value='Remove Carriage' name='remove[$key]' /></td></tr>";
                                }
                            }
                        ?>
                        <tr>
                            <td><select name="carriage">
                                <?php
                                    $result = mysqli_query($connection, "select carriageid,car.seattypeid,seattypename
                                        From carriage as car,seattype as seat 
                                        where  car.seattypeid = seat.seattypeid");
                                    while($row = mysqli_fetch_array($result)) {
                                ?>
                                <option value="<?php echo $row[0].'-'.$row[1].'-'.$row[2]; ?>"><?php echo $row[1]; ?>&nbsp;-&nbsp;<?php echo $row[2] ?></option>
                                <?php } ?></select>
                            </td>
                            <td style="text-align: center;">
                                <select name="serialno">
                                <?php
                                    for($i = 1; $i <= 20; $i++) {
                                        if(!array_key_exists($i, $_SESSION["carriages"])) {
                                            echo "<option>$i</option>";
                                        }
                                    }
                                ?>
                                </select>
                            </td> 
                            <td><input type="submit" name="add" value="Add Carriage"></td>
                        </tr>
                    </table>
                    <?php if(isset($_SESSION["carriages"])) { if(sizeof($_SESSION["carriages"]) > 0) { ?>
                    <input type="submit" name="save" value="Save" style="margin-top: 20px;" />
                    <?php } } ?>
                </form>
            </div>
        </div>
    </body>
</html>
