<?php
    session_start();
    include "./mysql_connect.php";
    
    if(isset($_POST["produce"]))
    {
       $station =$_POST["station"];
    }
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./css/style.css">

</head>

<body>
<form action="" method="post" name="dailyincomereport">
    <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php" style="color: #0099cc;">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
    <div class="above">
        <div class="reportheader" style="width: 300px;">
    <marquee direction="right" class="reportword">Online Myanmar Railway</marquee>
    </div>
        <div class="Login">
            <span class="Login-word" style="margin-left:0px; font-size:15px; font-weight:bold;">Unpaid Ticket Order by schedule one day in advance</span>
        </div>
        <div class="box">
            <div class="nn">
                <span style="font-family:Cooper; color:orange; font-size:21px;">Choose Station</span>  <select name="station" required>
                                    <option value="">Select station</option>
                                    <?php
                                        $result = mysqli_query($connection, "SELECT stationid,stationname FROM station");
                                        while($row = mysqli_fetch_array($result)) {
                                            $st = ($station == $row[0])? "selected": "";
                                    ?>
                                    <option value="<?php echo $row[0]; ?>" <?php echo $st; ?>><?php echo $row[1]; ?></option>
                                    <?php } ?>
                                    </select>
            </div>
            <input type="submit" name="produce" value="Produce" width="400px" class="but">
            <input type="submit" name="cancel-carriage" value="Cancel" width="400px" class="but" formnovalidate>
        </div>
         <?php
    
    if(isset($_POST["produce"]))
    {
   ?>
       <table border="2" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top: 30px; color:fuchsia;">
                        <tr bgcolor="cyan" style="color:fuchsia;">

                            <th>BookingDate</th>
                            <th>Customer Name</th>
                            <th>Contact Phone</th>
                            <th>Email</th>
                            <th>SeatNo</th> 
                                  
                        </tr>
    <?php $result = mysqli_query($connection, "Select         bookingdate
                                                ,             customername
                                                ,             customercontactphone
                                                ,             email
                                                ,             COUNT(seatno)
                                                From           schedule as sch                      
                                                ,              schedulecarriage as schcar
                                                ,            scheduledetail as schd
                                                ,            route as rou
                                                ,              ticket as tic
                                                ,              booking as boo
                                                ,              customer as cus
                                                Where          sch.scheduleid = schcar.scheduleid
                                                and          schcar.schedulecarriageid = schd.schedulecarriageid
                                                and          schd.schedulecarriageid = tic.schedulecarriageid
                                                and          schd.routeid = tic.routeid
                                                and            tic.bookingid             = boo.bookingid
                                                and          boo.customerid = cus.custommerid
                                                and            schd.routeid = rou.routeid
                                                and            boo.bookingid not in (select bookingid from payment)
                                                and          sch.depaturedate = DATE_ADD(curdate(), Interval 1 Day)
                                                and          rou.fromstation ='$station' GROUP BY customername;");
                while($row = mysqli_fetch_array($result)) { ?>
                        <tr>
                            <td><?php echo $row[0]; ?></td>
                            <td><?php echo $row[1]; ?></td>
                            <td><?php echo $row[2]; ?></td>
                            <td><?php echo $row[3]; ?></td>
                            <td><?php echo $row[4]; ?></td> 
                            
                        </tr>
                        <?php } ?>
                    </table>  
        
   <?php     

        
    }
    
       
?>

        </div>
           

    </div>
    </form>
</body>
</html>
