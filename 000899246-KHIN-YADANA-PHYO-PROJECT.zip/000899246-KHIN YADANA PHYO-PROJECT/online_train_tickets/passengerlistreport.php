<?php
    session_start();
include "./mysql_connect.php";

$reportdate = "";
if(isset($_POST["produce"]))
    {
        $reportdate = (isset($_POST["reportdate"]))? $_POST["reportdate"]: "";
    }
?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
         </script>
        
        <link rel="stylesheet" href="js/Datepicker/themes/ui-lightness/jquery.ui.all.css">
        <script src="js/jquery-2.1.1.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.core.min.js"></script>
        <script src="js/Datepicker/ui/minified/jquery.ui.datepicker.min.js"></script>
</head>
 <script>
    $(function() {
        $("#reportdate").datepicker();
        $("#reportdate").datepicker("option", "dateFormat", "yy-mm-dd");
        $("#reportdate").datepicker("option", "changeMonth", true);
        $("#reportdate").datepicker("option", "changeYear", true);
        $("#reportdate").datepicker("setDate", "<?php echo $reportdate; ?>");
    });
</script>
<body>
<form action="" method="post" name="dailyincomereport">
    <div class="logo">
                <div class="logo_word"><img src="images/200px-Myanma_Railway.svg.png" height="90px"></div>
                <?php if($_SESSION["staffrole"] == 'Admin') { ?>
                <div class="button" style="height: 80px;">
                    <ul style="margin-top: 0px;">
                        <li><a href="registercarriage.php">Carriage</a></li>
                        <li><a href="registerrouteprice.php">Price</a></li>
                        <li><a href="registerroute.php">Route</a></li>
                        <li><a href="register_schedule_1.php">Schedule</a></li>
                        <li><a href="registerseattype.php">Seat</a></li>
                        <li><a href="registerstaff.php">Staff</a></li>
                        <li><a href="registerstation.php">Station</a></li>
                        <li><a href="registertrain.php">Train</a></li>
                        <li><a href="adminreport.php" style="color: #0099cc;">Report</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } else { ?>
                <div class="button">
                    <ul>
                        <li><a href="confirm_ticket_payment.php">Payment</a></li>
                        <li><a href="closestation.php">Close</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
                <?php } ?>
            </div>
    <div class="above">
    <div class="reportheader" style="width: 300px;">
    <marquee direction="right" class="reportword">Online Myanmar Railway</marquee>
    </div>
        <div class="Login">
            <span class="Login-word" style="margin-left:0px; font-size:21px; font-weight:bold;">Passenger list by carriage by schedule</span>
        </div>
        <div class="box">
      <div class="nn">
              <span style="font-family:Cooper; color:orange; font-size:21px;">Report Date</span><input type="text" name="reportdate" id="reportdate" value="" style="width: 147px; height: 25px;"  />
                                <input type="button" value="Clear" name="clear" onclick="document.dailyincomereport.reportdate.value=''; submit();" style="height: 33px; margin-left: -10px;" />
            </div>
            <input type="submit" name="produce" value="Produce" width="400px" class="but">
            <input type="submit" name="cancel-carriage" value="Cancel" width="400px" class="but">
        </div>
         <?php
    
    if(isset($_POST["produce"]))
    {
   ?>
       <table border="2" bordercolor="yellow" bgcolor="cyan" width="100%" style="margin-top: 30px; color:fuchsia;">
                        <tr bgcolor="cyan" style="color:fuchsia;">

                            <th>ID Number</th>
                            <th>Traveller Name</th>
                            <th>Carriage Serial No</th>
                            <th>From Station</th>
                            <th>To Station</th> 
                            <th>Train Name</th> 
                            <th>Seat Type Name</th>  
                            <th>Seat No</th>      
                        </tr>
    <?php $result = mysqli_query($connection, "select   tic.idnumber
                                                            ,        tic.travellername
                                                            ,        carriageserialno
                                                            ,        fstat.stationname
                                                            ,        tstat.stationname
                                                            ,        trainname
                                                            ,        seattypename
                                                            ,        seatno
                                                            From     ticket as tic
                                                            ,        booking as boo
                                                            ,        payment as pay
                                                            ,        route as rou
                                                            ,        schedule as sch
                                                            ,        schedulecarriage as schcar
                                                            ,        scheduledetail as schd
                                                            ,        train as t
                                                            ,        routeprice as roup
                                                            ,        seattype as sea
                                                            ,        carriage as car
                                                            ,        (SELECT routeid, stationname FROM route r, station s
                                                                      WHERE r.fromstation = s.stationid) as fstat
                                                            ,        (SELECT routeid, stationname FROM route r, station s
                                                                      WHERE r.tostation = s.stationid) as tstat
                                                            Where    tic.bookingid = boo.bookingid
                                                            and      boo.bookingid = pay.bookingid
                                                            and      tic.routeid = rou.routeid
                                                            and      tic.schedulecarriageid = schd.schedulecarriageid
                                                            and      schd.routeid = tic.routeid
                                                            and      tic.schedulecarriageid = schcar.schedulecarriageid
                                                            and      schcar.scheduleid = sch.scheduleid
                                                            and      sch.trainid = t.trainid
                                                            and      tic.routeid = roup.routeid
                                                            and      schcar.carriageid = car.carriageid
                                                            and      car.seattypeid = roup.seattypeid
                                                            and      car.seattypeid = sea.seattypeid
                                                            and      rou.routeid = fstat.routeid
                                                            and      rou.routeid = tstat.routeid
                                                            and      sch.depaturedate = '$reportdate';");
                while($row = mysqli_fetch_array($result)) { ?>
                        <tr>
                            <td><?php echo $row[0]; ?></td>
                            <td><?php echo $row[1]; ?></td>
                            <td><?php echo $row[2]; ?></td>
                            <td><?php echo $row[3]; ?></td>
                            <td><?php echo $row[4]; ?></td> 
                            <td><?php echo $row[5]; ?></td> 
                            <td><?php echo $row[6]; ?></td> 
                            <td><?php echo $row[7]; ?></td> 
                        </tr>
                        <?php } ?>
                    </table>  
        
   <?php     

        
    }
    
       
?>

        </div>
           

    </div>
    </form>
</body>
</html>
