-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.6.21


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema online_train_tickets
--

CREATE DATABASE IF NOT EXISTS online_train_tickets;
USE online_train_tickets;

--
-- Definition of table `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `bookingid` varchar(8) NOT NULL,
  `bookingdate` date NOT NULL,
  `customerid` varchar(8) NOT NULL,
  PRIMARY KEY (`bookingid`),
  KEY `customerid` (`customerid`),
  CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`customerid`) REFERENCES `customer` (`custommerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` (`bookingid`,`bookingdate`,`customerid`) VALUES 
 ('B0000001','2015-11-24','C0000001'),
 ('B0000002','2015-11-25','C0000001'),
 ('B0000003','2015-11-24','C0000001'),
 ('B0000004','2015-11-25','C0000002');
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;


--
-- Definition of table `carriage`
--

DROP TABLE IF EXISTS `carriage`;
CREATE TABLE `carriage` (
  `carriageid` varchar(8) NOT NULL,
  `seattypeid` varchar(8) NOT NULL,
  `totalseat` int(10) unsigned NOT NULL,
  `seatperrow` int(10) unsigned NOT NULL,
  PRIMARY KEY (`carriageid`),
  KEY `FK_carriage_seattypeid` (`seattypeid`),
  CONSTRAINT `FK_carriage_seattypeid` FOREIGN KEY (`seattypeid`) REFERENCES `seattype` (`seattypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carriage`
--

/*!40000 ALTER TABLE `carriage` DISABLE KEYS */;
INSERT INTO `carriage` (`carriageid`,`seattypeid`,`totalseat`,`seatperrow`) VALUES 
 ('C001','S001',64,4),
 ('C002','S002',64,4),
 ('C003','S003',40,4),
 ('C004','S004',18,2);
/*!40000 ALTER TABLE `carriage` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `custommerid` varchar(8) NOT NULL,
  `customername` varchar(25) NOT NULL,
  `customercontactphone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  PRIMARY KEY (`custommerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`custommerid`,`customername`,`customercontactphone`,`email`,`password`) VALUES 
 ('C0000001','Khin Yadana Phyo','09253104501','phyo@gmail.com','$2y$10$.YcclqccP7QEQ6K3A2qI3uFbR9174YefPYdoeYValRlClk92ZBlbK'),
 ('C0000002','Thu Thu','09253104501','thu@gmail.com','$2y$10$tqmZzEym8OprnPsBTpcPMOg61SZIDhxAXQL34eFSYr5PTj2AApzKS'),
 ('C0000003','SHIN MIN','09253104501','shinmin@gmail.com','$2y$10$aOgA41bwSzIYkILlRU1QlOJHqN8alJ6jrBoCxO8eQCoHBHfsa/jfe');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `paymentid` varchar(8) NOT NULL,
  `paymentdate` date NOT NULL,
  `bookingid` varchar(8) NOT NULL,
  `staffid` varchar(8) NOT NULL,
  PRIMARY KEY (`paymentid`),
  KEY `FK_payment_bookingid` (`bookingid`),
  KEY `FK_payment_staffid` (`staffid`),
  CONSTRAINT `FK_payment_bookingid` FOREIGN KEY (`bookingid`) REFERENCES `booking` (`bookingid`),
  CONSTRAINT `FK_payment_staffid` FOREIGN KEY (`staffid`) REFERENCES `staff` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` (`paymentid`,`paymentdate`,`bookingid`,`staffid`) VALUES 
 ('P0000001','2015-11-25','B0000001','S002'),
 ('P0000002','2015-11-25','B0000002','S002'),
 ('P0000003','2015-11-30','B0000003','S002'),
 ('P0000004','2015-11-30','B0000004','S002');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;


--
-- Definition of table `route`
--

DROP TABLE IF EXISTS `route`;
CREATE TABLE `route` (
  `routeid` varchar(8) NOT NULL,
  `fromstation` varchar(8) NOT NULL,
  `tostation` varchar(8) NOT NULL,
  `travellingtime` time NOT NULL,
  `miles` decimal(10,0) NOT NULL,
  `restingtime` time NOT NULL,
  PRIMARY KEY (`routeid`),
  KEY `fromstation` (`fromstation`),
  KEY `tostation` (`tostation`),
  CONSTRAINT `route_ibfk_1` FOREIGN KEY (`fromstation`) REFERENCES `station` (`stationid`),
  CONSTRAINT `route_ibfk_2` FOREIGN KEY (`tostation`) REFERENCES `station` (`stationid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `route`
--

/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` (`routeid`,`fromstation`,`tostation`,`travellingtime`,`miles`,`restingtime`) VALUES 
 ('R001','S001','S002','02:00:00','56','00:05:00'),
 ('R002','S001','S003','06:00:00','180','00:15:00'),
 ('R003','S001','S004','09:00:00','300','00:10:00'),
 ('R004','S001','S005','12:00:00','420','00:15:00');
/*!40000 ALTER TABLE `route` ENABLE KEYS */;


--
-- Definition of table `routeprice`
--

DROP TABLE IF EXISTS `routeprice`;
CREATE TABLE `routeprice` (
  `routeid` varchar(8) NOT NULL,
  `seattypeid` varchar(8) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`routeid`,`seattypeid`),
  KEY `FK_routeprice_seattypeid` (`seattypeid`),
  CONSTRAINT `FK_routeprice_routeid` FOREIGN KEY (`routeid`) REFERENCES `route` (`routeid`),
  CONSTRAINT `FK_routeprice_seattypeid` FOREIGN KEY (`seattypeid`) REFERENCES `seattype` (`seattypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routeprice`
--

/*!40000 ALTER TABLE `routeprice` DISABLE KEYS */;
INSERT INTO `routeprice` (`routeid`,`seattypeid`,`price`) VALUES 
 ('R001','S001',700),
 ('R001','S002',800),
 ('R002','S001',1500),
 ('R002','S002',2000),
 ('R002','S003',3000),
 ('R003','S001',2200),
 ('R003','S002',3000),
 ('R003','S003',4500),
 ('R004','S001',5000),
 ('R004','S002',6500),
 ('R004','S003',8000);
/*!40000 ALTER TABLE `routeprice` ENABLE KEYS */;


--
-- Definition of table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE `schedule` (
  `scheduleid` varchar(8) NOT NULL,
  `scheduledate` date NOT NULL,
  `depaturedate` date NOT NULL,
  `departuretime` time NOT NULL,
  `trainid` varchar(8) NOT NULL,
  PRIMARY KEY (`scheduleid`) USING BTREE,
  KEY `FK_schedule_trainid` (`trainid`),
  CONSTRAINT `FK_schedule_trainid` FOREIGN KEY (`trainid`) REFERENCES `train` (`trainid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` (`scheduleid`,`scheduledate`,`depaturedate`,`departuretime`,`trainid`) VALUES 
 ('Sch001','2015-11-24','2015-11-30','06:00:00','T001'),
 ('Sch002','2015-11-25','2015-11-26','08:00:00','T001'),
 ('Sch003','2015-11-24','2015-11-30','07:00:00','T001');
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;


--
-- Definition of table `schedulecarriage`
--

DROP TABLE IF EXISTS `schedulecarriage`;
CREATE TABLE `schedulecarriage` (
  `schedulecarriageid` varchar(8) NOT NULL,
  `scheduleid` varchar(8) NOT NULL,
  `carriageid` varchar(8) NOT NULL,
  `carriageserialno` int(10) unsigned NOT NULL,
  PRIMARY KEY (`schedulecarriageid`),
  KEY `FK_schedulecarriage_scheduleid` (`scheduleid`),
  KEY `FK_schedulecarriage_carriageid` (`carriageid`),
  CONSTRAINT `FK_schedulecarriage_carriageid` FOREIGN KEY (`carriageid`) REFERENCES `carriage` (`carriageid`),
  CONSTRAINT `FK_schedulecarriage_scheduleid` FOREIGN KEY (`scheduleid`) REFERENCES `schedule` (`scheduleid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedulecarriage`
--

/*!40000 ALTER TABLE `schedulecarriage` DISABLE KEYS */;
INSERT INTO `schedulecarriage` (`schedulecarriageid`,`scheduleid`,`carriageid`,`carriageserialno`) VALUES 
 ('Scar0001','Sch001','C001',1),
 ('Scar0002','Sch001','C001',2),
 ('Scar0003','Sch001','C003',3),
 ('Scar0004','Sch002','C002',1),
 ('Scar0005','Sch003','C001',1),
 ('Scar0006','Sch003','C002',2);
/*!40000 ALTER TABLE `schedulecarriage` ENABLE KEYS */;


--
-- Definition of table `scheduledetail`
--

DROP TABLE IF EXISTS `scheduledetail`;
CREATE TABLE `scheduledetail` (
  `schedulecarriageid` varchar(8) NOT NULL,
  `routeid` varchar(8) NOT NULL,
  `seatnumbers` varchar(255) NOT NULL,
  PRIMARY KEY (`routeid`,`schedulecarriageid`) USING BTREE,
  KEY `FK_scheduledetail_schedulecarriageid` (`schedulecarriageid`),
  CONSTRAINT `FK_scheduledetail_routeid` FOREIGN KEY (`routeid`) REFERENCES `route` (`routeid`),
  CONSTRAINT `FK_scheduledetail_schedulecarriageid` FOREIGN KEY (`schedulecarriageid`) REFERENCES `schedulecarriage` (`schedulecarriageid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scheduledetail`
--

/*!40000 ALTER TABLE `scheduledetail` DISABLE KEYS */;
INSERT INTO `scheduledetail` (`schedulecarriageid`,`routeid`,`seatnumbers`) VALUES 
 ('Scar0001','R001','1#2#3#4'),
 ('Scar0002','R001','1#2#3#4'),
 ('Scar0003','R001','1#2#3#4'),
 ('Scar0004','R001','1#2#3#4'),
 ('Scar0005','R001','1#2#3#4#8#7#6#5'),
 ('Scar0006','R001','1#2#3#4#8#6#7#5'),
 ('Scar0001','R002','5#6#7#8'),
 ('Scar0002','R002','5#6#7#8'),
 ('Scar0003','R002','5#6#7#8'),
 ('Scar0004','R002','5#7#6#8'),
 ('Scar0001','R003','9#10#11#12'),
 ('Scar0002','R003','9#10#11#12'),
 ('Scar0003','R003','9#10#11#12'),
 ('Scar0001','R004','13#14#15#16'),
 ('Scar0002','R004','14#13#15#16'),
 ('Scar0003','R004','13#14#15#16');
/*!40000 ALTER TABLE `scheduledetail` ENABLE KEYS */;


--
-- Definition of table `schedulestation`
--

DROP TABLE IF EXISTS `schedulestation`;
CREATE TABLE `schedulestation` (
  `scheduleid` varchar(8) NOT NULL,
  `stationid` varchar(8) NOT NULL,
  `proposeddepaturetime` time NOT NULL,
  `realdepaturetime` time DEFAULT NULL,
  `depaturestatus` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`scheduleid`,`stationid`),
  KEY `FK_schedulestation_stationid` (`stationid`),
  CONSTRAINT `FK_schedulestation_scheduleid` FOREIGN KEY (`scheduleid`) REFERENCES `schedule` (`scheduleid`),
  CONSTRAINT `FK_schedulestation_stationid` FOREIGN KEY (`stationid`) REFERENCES `station` (`stationid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedulestation`
--

/*!40000 ALTER TABLE `schedulestation` DISABLE KEYS */;
INSERT INTO `schedulestation` (`scheduleid`,`stationid`,`proposeddepaturetime`,`realdepaturetime`,`depaturestatus`) VALUES 
 ('Sch001','S001','06:00:00','03:04:05',1),
 ('Sch001','S002','08:05:00','00:00:00',0),
 ('Sch001','S003','12:15:00',NULL,NULL),
 ('Sch001','S004','15:10:00',NULL,NULL),
 ('Sch001','S005','18:15:00',NULL,NULL),
 ('Sch002','S001','08:00:00',NULL,NULL),
 ('Sch002','S002','10:05:00',NULL,NULL),
 ('Sch002','S003','14:15:00',NULL,NULL),
 ('Sch003','S001','07:00:00',NULL,NULL),
 ('Sch003','S002','09:05:00',NULL,NULL);
/*!40000 ALTER TABLE `schedulestation` ENABLE KEYS */;


--
-- Definition of table `seattype`
--

DROP TABLE IF EXISTS `seattype`;
CREATE TABLE `seattype` (
  `seattypeid` varchar(8) NOT NULL,
  `seattypename` varchar(25) NOT NULL,
  PRIMARY KEY (`seattypeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seattype`
--

/*!40000 ALTER TABLE `seattype` DISABLE KEYS */;
INSERT INTO `seattype` (`seattypeid`,`seattypename`) VALUES 
 ('S001','Ordinary Class'),
 ('S002','First Class'),
 ('S003','Upper Class 4'),
 ('S004','Sleeper Class'),
 ('S005','Upper Class 3');
/*!40000 ALTER TABLE `seattype` ENABLE KEYS */;


--
-- Definition of table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff` (
  `staffid` varchar(8) NOT NULL,
  `staffname` varchar(35) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `staffrole` varchar(25) NOT NULL,
  `stationid` varchar(8) NOT NULL,
  PRIMARY KEY (`staffid`),
  KEY `FK_staff_stationid` (`stationid`),
  CONSTRAINT `FK_staff_stationid` FOREIGN KEY (`stationid`) REFERENCES `station` (`stationid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` (`staffid`,`staffname`,`email`,`password`,`staffrole`,`stationid`) VALUES 
 ('S001','Admin','admin@gmail.com','$2y$10$9FNH/085nGl93gECxgsL9uFNk6AzF9PkQRkEAvOzAKQdC.L6tf0ti','Admin','S001'),
 ('S002','Tun Tun','tuntun@gmail.com','$2y$10$ufs2tLBy2bQRVdnueQXBz.rdbRue2.Kc2iD0krtT2F0DL8QLY6Sq.','Station Officer','S001'),
 ('S003','Kyaw Kyaw','kyawkyaw@gmail.com','$2y$10$hk.RPFor5J/gtcLcxccy.OyQVefnehkcCGGRrFuVopOeDFtZdrVfW','Station Officer','S002'),
 ('S004','Aung Aung','aungaung@gmail.com','$2y$10$G5.F8oWb0Lk/zglh4Dol4u6kM64Lq4P3Qy4P8hivmMXFYWysQhy36','Station Officer','S003');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;


--
-- Definition of table `station`
--

DROP TABLE IF EXISTS `station`;
CREATE TABLE `station` (
  `stationid` varchar(8) NOT NULL,
  `stationname` varchar(25) NOT NULL,
  PRIMARY KEY (`stationid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `station`
--

/*!40000 ALTER TABLE `station` DISABLE KEYS */;
INSERT INTO `station` (`stationid`,`stationname`) VALUES 
 ('S001','Yangon'),
 ('S002','Bago'),
 ('S003','Taungoo'),
 ('S004','Tharzi'),
 ('S005','Mandalay');
/*!40000 ALTER TABLE `station` ENABLE KEYS */;


--
-- Definition of table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
CREATE TABLE `ticket` (
  `ticketid` varchar(8) NOT NULL,
  `seatno` varchar(10) NOT NULL,
  `travellername` varchar(30) NOT NULL,
  `idnumber` varchar(45) NOT NULL,
  `routeid` varchar(8) NOT NULL,
  `schedulecarriageid` varchar(8) NOT NULL,
  `bookingid` varchar(8) NOT NULL,
  PRIMARY KEY (`ticketid`) USING BTREE,
  KEY `FK_ticket_routeid` (`routeid`),
  KEY `FK_ticket_schedulecarriageid` (`schedulecarriageid`),
  KEY `FK_ticket_bookingid` (`bookingid`),
  CONSTRAINT `FK_ticket_bookingid` FOREIGN KEY (`bookingid`) REFERENCES `booking` (`bookingid`),
  CONSTRAINT `FK_ticket_routeid` FOREIGN KEY (`routeid`) REFERENCES `route` (`routeid`),
  CONSTRAINT `FK_ticket_schedulecarriageid` FOREIGN KEY (`schedulecarriageid`) REFERENCES `scheduledetail` (`schedulecarriageid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket`
--

/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` (`ticketid`,`seatno`,`travellername`,`idnumber`,`routeid`,`schedulecarriageid`,`bookingid`) VALUES 
 ('Tic00001','13','Mg Mg','112233','R004','Scar0001','B0000001'),
 ('Tic00002','14','Ag Ag','445566','R004','Scar0001','B0000001'),
 ('Tic00003','1','Aye Aye','012345','R001','Scar0001','B0000002'),
 ('Tic00004','2','Hla Hla','456789','R001','Scar0001','B0000002'),
 ('Tic00005','3','hh','1234','R001','Scar0001','B0000003'),
 ('Tic00006','4','jj','3455','R001','Scar0001','B0000003'),
 ('Tic00007','1','BIG PHYO','1234','R001','Scar0002','B0000004'),
 ('Tic00008','2','SMALL PHYO','5678','R001','Scar0002','B0000004');
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;


--
-- Definition of table `train`
--

DROP TABLE IF EXISTS `train`;
CREATE TABLE `train` (
  `trainid` varchar(8) NOT NULL,
  `trainname` varchar(25) NOT NULL,
  `tripname` varchar(25) NOT NULL,
  PRIMARY KEY (`trainid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `train`
--

/*!40000 ALTER TABLE `train` DISABLE KEYS */;
INSERT INTO `train` (`trainid`,`trainname`,`tripname`) VALUES 
 ('T001','11 Up','Yangon - Mandalay'),
 ('T002','12 Down','Mandalay - Yangon');
/*!40000 ALTER TABLE `train` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
